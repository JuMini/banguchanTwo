angular.module('grammer_extension', ['ui.router', 'ngSanitize', 'ngResource', 'ngLodash'])
	.config(['$qProvider', function ($qProvider) {
	    $qProvider.errorOnUnhandledRejections(false);
	}])

	.run(function($rootScope, resourceService, stringService) {

		// Intercept Requests
		chrome.webRequest.onBeforeSendHeaders.addListener(
			function(e){
				// Instagram
				angular.forEach(e.requestHeaders, function(header, header_index){
					if(header&&header.name=="Cookie"){
						if(header.value&&(header.value.indexOf('ds_user_id')>-1)){
							$rootScope.username_id = stringService.getSplit(header.value, 'ds_user_id=', ';');
						}
					}
				});

				// Youtube
				angular.forEach(e.requestHeaders, function(header, header_index){
					if(header&&header.name=="X-Client-Data")
						$rootScope.targeted_headerValue = header.value;
				});
			},
			{urls: [
				"https://www.youtube.com/*",
				"https://band.us/*",
				"https://www.instagram.com/*"
			]},
			["blocking", "requestHeaders"]
		);

		// 1. tabs[i].url에 staticxx.facebook.com/connect/ 가 포함되어 있으면 www.instagram.com으로 페이지 이동
		chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab){
			chrome.tabs.query({}, function(tabs){
				var prohibitted_url = 'staticxx.facebook.com/connect/';
				for(var i=0; i<tabs.length; i++){
					var tab_url = tabs[i].url;
					var tab_id = tabs[i].id;
					if(tab_url.indexOf(prohibitted_url)>=0){
						chrome.tabs.sendMessage(
							tab_id,
							{command:'goToPage', value:'https://www.instagram.com'},
							function(response){}
						);
					}
				};
			})
		})

		// 2. grammer_excute's checkIdentificationFromDB in grammerCheckService!
		chrome.runtime.onMessage.addListener(
		  function(request, sender, sendResponse) {
		  	// 그래머 프로그램 스타트할 수 있게 하는 로직
		  	if(request&&request.resource_url&&request.grammer_key&&request.identification){
			  	resourceService.resourceExternalUrl(request.resource_url, request.grammer_key, request.identification).then(function(response){
			  		sendResponse(response);
			  		return true;
			  	});
			  	return true;
		  	}

		  	// 그래머 버전 확인하고 업데이트 있으면 알림 띄우는 로직
		  	if(request&&request.resource_url&&request.grammer_version_using){
		  		resourceService.resourceGrammerVersion(request.resource_url, request.grammer_version_using).then(function(response){
		  			sendResponse(response);
		  			return true;
		  		});
		  		return true;
		  	}

		  	// 인스타그래머 프로그램 (팔로워, 팔로잉) 리스트를 각각 서버에 저장할 수 있게 하는 로직
		  	if(request&&request.resource_url&&request.user_name&&request.password){
		  		resourceService.resourceInstagrammerAccountInfo(request.resource_url, request.user_name, request.password).then(function(response){
		  			sendResponse(response);
		  			return true;
		  		});
		  		return true;
		  	}

		  	// 서버에 저장된 팔로워, 팔로잉을 가져오게 하는 로직
		  	if(request&&request.resource_url&&request.user_name){
		  		resourceService.resourceInstagrammerAccountInfoTwo(request.resource_url, request.user_name).then(function(response){
		  			sendResponse(response);
		  			return true;
		  		});
		  		return true;
		  	}

		  	// 구동하는 계정의 is_active 여부를 확인하고, 비활성화해야 할 때 처리하는 로직
		  	if(request&&request.grammer_key&&request.account_id){
		  		resourceService.resourceAccountStateChange(request.grammer_key, request.account_id, request.is_active_value).then(function(response){
		  			sendResponse(response);
		  			return true;
		  		});
		  		return true;
		  	}

		  	// InstagramSwitchService에서 인스타그램 게시물 가져오는 로직
		  	if(request&&request.resource_url&&request.instagram_account){
		  		resourceService.resourceCrawlInstagramBulletinNotUploaded(request.resource_url, request.instagram_account).then(function(response){
		  			sendResponse(response);
		  			return true;
		  		});
		  		return true;
		  	}

		  	// Instagram 게시물 업로드하는 로직
		  	if(request&&request.resource_url&&request.bulletin_id&&request.username_upload&&request.password&&request.photo&&request.caption){
		  		resourceService.resourceUploadBulletin(request.resource_url, request.bulletin_id, request.username_upload, request.password, request.photo, request.caption).then(function(response){
		  			sendResponse(response);
		  			return true;
		  		});
		  		return true;
		  	}

		  	// YoutugrammerUnfollowService 구동시에 X-Client-Data를 가져오는 로직
		  	if(request&&request.message&&request.message=='crawlXClientData'){
		  		sendResponse($rootScope.targeted_headerValue);
		  		return true;
		  	}
		  }
		);
	})

	.service('stringService', function(){

		this.checkStringLength = function(string){
			var self = this;
			if(angular.isString(string)&&string.length>=1) return true;
			return false;
		};

		this.getSplit = function(string, split1, split2){
			var self = this;
			if(!self.checkStringLength(string)) return '';
			if((split1&&string.indexOf(split1)==-1)&&(split2&&string.indexOf(split2)==-1)) return null;
			if(self.checkStringLength(string)&&split1&&self.checkStringLength(split1)&&(string.indexOf(split1)!=-1)) string = string.split(split1)[1];
			if(self.checkStringLength(string)&&split2&&self.checkStringLength(split2)&&(string.indexOf(split2)!=-1)) string = string.split(split2)[0];
			if(!(string&&string.length>=1)) return null;
			string = string.replace(/\s/g,"");
			return string;
		};

	})

	.service('resourceService', function($q, $resource, $rootScope, grammersService){

		// Resource Function Section
		this.resourceAccountStateChange = function(grammer_key, account_id, is_active_value){
			var self = this;
			return $q(function(resolve, reject){
				grammersService.getGrammerAccountServiceFromGrammerKey(grammer_key).update({
					id: account_id,
					is_active: is_active_value
				}, function(response){
					resolve(response);
				});
			});
		};

		this.resourceCrawlInstagramBulletinNotUploaded = function(resource_url, instagram_account){
			var self = this;
			return $q(function(resolve, reject){
				var resource = $resource(resource_url);
				resource.get({instagram_account:instagram_account}, function(response){
					resolve(response);
				});
			});
		};

		// request.resource_url, request.user_name, request.password, request.photo, request.caption
		this.resourceUploadBulletin = function(resource_url, bulletin_id, user_name, password, photo, caption){
			var self = this;
			return $q(function(resolve, reject){
				var resource = $resource(resource_url);
				resource.get({
					resource_url: resource_url,
					bulletin_id: bulletin_id,
					username_upload: user_name,
					password: password,
					photo: photo,
					caption: caption
				}, function(response){
					resolve(response);
				});
			});
		};

		this.resourceGrammerVersion = function(resource_url, grammer_version_using){
			var self = this;
			return $q(function(resolve, reject){
				var resource = $resource(resource_url);
				resource.get({grammer_version_using:grammer_version_using}, function(response){
					resolve(response);
				});
			});
		};

		this.resourceExternalUrl = function(resource_url, grammer_key, identification){
			var self = this;
			return $q(function(resolve, reject){
				var resource = $resource(resource_url);
				resource.get({grammer_name_en:grammer_key, identification:identification}, function(response){
					resolve(response);
				});
			});
		};

		this.resourceInstagrammerAccountInfo = function(resource_url, user_name, password){
			var self = this;
			return $q(function(resolve, reject){
				var resource = $resource(resource_url);
				resource.get({user_name:user_name, password:password, username_id: $rootScope.username_id}, function(response){
					resolve(response);
				});
			});
		};

		this.resourceInstagrammerAccountInfoTwo = function(resource_url, user_name){
			var self = this;
			return $q(function(resolve, reject){
				var resource = $resource(resource_url);
				resource.get({user_name:user_name}, function(response){
					resolve(response);
				});
			});
		};
	})



	.service('grammersService', function(BlogAccountService, FacebookAccountService, InstagramAccountService, KakaostoryAccountService, PholarAccountService, TwitterAccountService,
	VingleAccountService, YoutubeAccountService, PostAccountService){

		// Get Function Section
		this.getGrammerAccountServiceFromGrammerKey = function(grammer_key){
			if(grammer_key=='blogrammer') return BlogAccountService;
			if(grammer_key=='facegrammer') return FacebookAccountService;
			if(grammer_key=='instagrammer') return InstagramAccountService;
			if(grammer_key=='kakaogrammer') return KakaostoryAccountService;
			if(grammer_key=='pholagrammer') return PholarAccountService;
			if(grammer_key=='postgrammer') return PostAccountService;
			if(grammer_key=='twitgrammer') return TwitterAccountService;
			if(grammer_key=='vingrammer')	return VingleAccountService;
			if(grammer_key=='youtugrammer') return YoutubeAccountService;
		};

	})

	// .constant('ServerURL','http://127.0.0.1:8080/') // LOCAL
	// .constant('ServerURL','http://ebGrammerApp-cover-env.ap-northeast-1.elasticbeanstalk.com/') // cover 
	// .constant('ServerURL','http://ebGrammerApp.ap-northeast-2.elasticbeanstalk.com/') // sangho
	// .constant('ServerURL','http://ebGrammerApp-kimcorp-env.ap-northeast-1.elasticbeanstalk.com/') // kiup
	// .constant('ServerURL','http://ebgrammerapp-changdae.ap-northeast-1.elasticbeanstalk.com/') // dalgom
	.constant('ServerURL','http://eb-grammer-app-dev.ap-northeast-2.elasticbeanstalk.com/') // REMOTE
	.constant('BlogAccountURL','BlogAccount/')
	.constant('FacebookAccountURL','FacebookAccount/')
	.constant('InstagramAccountURL','InstagramAccount/')
	.constant('KakaostoryAccountURL','KakaostoryAccount/')
	.constant('PholarAccountURL','PholarAccount/')
	.constant('TwitterAccountURL','TwitterAccount/')
	.constant('VingleAccountURL','VingleAccount/')
	.constant('YoutubeAccountURL','YoutubeAccount/')
	.constant('PostAccountURL','PostAccount/')

	.factory('BlogAccountService', function($resource, ServerURL, BlogAccountURL){ return $resource(ServerURL+BlogAccountURL+':id/',{id: '@id'},{'update': { method:'PUT'}}); })
	.factory('FacebookAccountService', function($resource, ServerURL, FacebookAccountURL){ return $resource(ServerURL+FacebookAccountURL+':id/',{id: '@id'},{'update': { method:'PUT'}}); })
	.factory('InstagramAccountService', function($resource, ServerURL, InstagramAccountURL){ return $resource(ServerURL+InstagramAccountURL+':id/',{id: '@id'},{'update': { method:'PUT'}}); })
	.factory('KakaostoryAccountService', function($resource, ServerURL, KakaostoryAccountURL){ return $resource(ServerURL+KakaostoryAccountURL+':id/',{id: '@id'},{'update': { method:'PUT'}}); })
	.factory('PholarAccountService', function($resource, ServerURL, PholarAccountURL){ return $resource(ServerURL+PholarAccountURL+':id/',{id: '@id'},{'update': { method:'PUT'}}); })
	.factory('TwitterAccountService', function($resource, ServerURL, TwitterAccountURL){ return $resource(ServerURL+TwitterAccountURL+':id/',{id: '@id'},{'update': { method:'PUT'}}); })
	.factory('VingleAccountService', function($resource, ServerURL, VingleAccountURL){ return $resource(ServerURL+VingleAccountURL+':id/',{id: '@id'},{'update': { method:'PUT'}}); })
	.factory('YoutubeAccountService', function($resource, ServerURL, YoutubeAccountURL){ return $resource(ServerURL+YoutubeAccountURL+':id/',{id: '@id'},{'update': { method:'PUT'}}); })
	.factory('PostAccountService', function($resource, ServerURL, PostAccountURL){ return $resource(ServerURL+PostAccountURL+':id/',{id: '@id'},{'update': { method:'PUT'}}); })
