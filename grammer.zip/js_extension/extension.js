/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	__webpack_require__(1);
	__webpack_require__(2);
	__webpack_require__(3);
	__webpack_require__(4);
	__webpack_require__(5);
	__webpack_require__(6);
	__webpack_require__(7);
	__webpack_require__(8);
	__webpack_require__(9);
	__webpack_require__(10);
	__webpack_require__(11);
	__webpack_require__(12);
	__webpack_require__(13);
	__webpack_require__(14);
	__webpack_require__(15);
	__webpack_require__(16);
	__webpack_require__(17);
	__webpack_require__(18);
	__webpack_require__(19);
	__webpack_require__(20);
	__webpack_require__(21);
	__webpack_require__(22);


/***/ },
/* 1 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension",['ui.router', 'ngSanitize', 'ngResource', 'ngLodash'])
		// Possibly unhandled rejection 다루는 로직
		.config(['$qProvider', function ($qProvider) {
		    $qProvider.errorOnUnhandledRejections(false);
		}])

		.run(function($rootScope, $state, $timeout, arrayService, stringService, urlService, grammerGetService, grammerCheckService, grammerInitializeService, grammerSetService, lodash) {
			$rootScope._ = lodash;

			$rootScope.test_on_extension = 1;

			// Go Function Section
			$rootScope.goToPage = function(page, id, data){
				if(id<1) id=null;
				$state.go(page, {'id':id, 'data':data});
			};

			// What Function Section
			$rootScope.what = function(obj){
				console.log(obj);
			};

			// Set Function Section
			var timeoutPromise;
			$rootScope.setGrammer = function(grammer_key){
				$timeout.cancel(timeoutPromise);
				grammerGetService.getGrammer(grammer_key).then(function(grammer_value){
					$rootScope.goToPage('detail/:id', grammer_key);
					timeoutPromise = $timeout(function(){
						urlService.getUrl().then(function(url){
							if(angular.isString(grammer_value.host)){
								// grammer_value.host가 url에 포함되어있지 않은 경우에 urlService.setUrl을 호출한다.
								if(!_.includes(url, grammer_value.host)) urlService.setUrl(grammer_value.url);
							}
							else if(angular.isArray(grammer_value.host)){
								var mismatching_index = 0;
								// grammer_value.host에 있는 url중 어떤 것과도 매치가 되지 않았을 때에 urlService.setUrl을 호출한다.
								angular.forEach(grammer_value.host, function(host_element, host_element_index){
									if(!_.includes(url, host_element)) mismatching_index += 1;
									if(mismatching_index>=grammer_value.host.length) urlService.setUrl(grammer_value.url);
								});
							}
						});
					}, 1000);
				}, function(){
					return;
				});
			};

			$rootScope.setGrammerKeyOfGrammerStorageWithUrl = function(){
				// 1. url로 grammer_key를 가져온다.
				// 2. 가져온 grammer_key를 크롬 확장 DB에 grammer_storage에 넣어서 set한다.
				// 3. 2가 끝난 후 돌아온 response에 있는 grammer_key를 앞단에 저장한다.
				grammerGetService.getGrammerKeyWithUrl().then(function(grammer_key){
					grammerSetService.setGrammerKey(grammer_key).then(function(grammer_key){
						$rootScope.setGrammer(grammer_key);
					});
				});
			};

			$rootScope.initialize = function(){
				grammerInitializeService.initializeGrammerStorage().then(function(grammer_storage){
					$rootScope.setGrammerKeyOfGrammerStorageWithUrl();
				}, function(){
					return;
				});
			};
			$rootScope.initialize();

			// On Function Section
			$rootScope.$on('$stateChangeStart', function(event, toState, toParams, fromState, fromParams){
				$rootScope.state = toState.name;
			});

			/*chrome.runtime.onMessage.addListener(
			  function(request, sender, sendResponse) {
			  	console.log('요청옴');
			  	console.log(request.resource_url);
			  	console.log(request.grammer_key);
			  	console.log(request.version_key);
			  	console.log(request.identification);
			  	// var resource = $re


			    // if (request.greeting == "hello")
			    //   sendResponse({farewell: "goodbye"});
			  }
			);*/
		});


/***/ },
/* 2 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.config(function ($httpProvider, $stateProvider, $urlRouterProvider, $resourceProvider, $compileProvider) {
			$httpProvider.defaults.xsrfCookieName = 'csrftoken';
			$httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
			$resourceProvider.defaults.stripTrailingSlashes = false;
			$compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|local|data|chrome-extension):/);

			$stateProvider
				.state('list', {
					url: '/list',
					templateUrl: 'templates_extension/list/list.html',
					controller: 'ListCtrl'
				})
				.state('detail/:id', {
					url: '/detail/:id',
					templateUrl: 'templates_extension/detail/detail.html',
					controller: 'DetailCtrl'
				});
			
			$urlRouterProvider.otherwise('/list');
		});

/***/ },
/* 3 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('stringService', function($rootScope){
			this.checkString = function(string){
				if(angular.isString(string)) return true;
				return false;
			};
			this.checkStringLength = function(string){
				var self = this;
				if(angular.isString(string)&&string.length>=1) return true;
				return false;
			};
			this.getUppercaseOfString = function(string){
				return angular.uppercase(string);
			};
			this.getLowercaseOfString = function(string){
				return angular.lowercase(string);
			};
			this.compareWithoutCapital = function(string1, string2){
				var self = this;
				if(self.getLowercaseOfString(string1)==self.getLowercaseOfString(string2)) return true;
				else return false;
			};
			this.containString1InString2WithoutCapital = function(string1, string2){
				var self = this;
				string1 = String(string1);
				string2 = String(string2);
				if(self.getLowercaseOfString(string2).indexOf(self.getLowercaseOfString(string1))!==-1){ return true;}
				else{ return false;}
			};
			this.makeString = function(string){
				return String(string);
			};
		});

/***/ },
/* 4 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('arrayService', function($rootScope, $q, stringService){
			this.makeArray = function(string, split){
				if(angular.isArray(string)) return string;
				else if(angular.isString(string)) return string.split(split);
				else return [];
			};
			this.hasItems = function(array){
				try{
					if(!angular.isArray(array)) return false;
					return array.length>=1;
				}catch(e){
					return false;
				}
			};
			this.getRandom = function(array){
				if(!angular.isArray(array)) return null;
				return array[Math.floor(Math.random()*array.length)];
			};
			this.existWordsInString = function(words, string){
				var self = this;
				return $q(function(resolve, reject){
					if(!self.hasItems(words)){ resolve(false); return; }
					angular.forEach(words, function(word, word_index){
						word = word.replace(/\s/g,"");
		  			if(stringService.checkStringLength(word)&&string.indexOf(word)!==-1){ 
		  				resolve(true); 
		  				return;
		  			}
		  			if(word_index==(words.length-1)){
		  				resolve(false);
		  				return;
		  			}
		  		});
				});
			};
		});

/***/ },
/* 5 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('numberService', function($rootScope){
			// Get Function Section
			this.getRandomOfNumber = function(number, percentage){
				number = Number(number);
				if(!(angular.isNumber(number)&&number>=1)) return 0; 
				if(Math.random()<0.5) return Math.floor(number + Math.random()*number*percentage*0.01);
				else return Math.floor(number - Math.random()*number*percentage*0.01);
			};

			// Is Function Section
			this.isPositive = function(number){
				if(angular.isNumber(number)&&number>0) return true;
				else return false;
			};
			this.isSame = function(number1, number2){
				return Number(number1)==Number(number2);
			};
			
			// Make Function Section
			this.makeNumber = function(number){
				number = Math.floor(Number(number));
				if(!(angular.isNumber(number)&&number>=1)) return 0; 
				return number;
			};

			// Set Function Section
			this.setNumberInRange = function(number, range1, range2){
				var self = this;
				number = self.makeNumber(number);
				if(range1&&number<range1){
					range1 = self.makeNumber(range1);
					number += range1;
				}
				if(range2&&number>range2){
					range2 = self.makeNumber(range2);
					number = number%range2;
				}
				if(range1&&number<range1){
					range1 = self.makeNumber(range1);
					number += range1;
				}
				return number;
			};
		});

/***/ },
/* 6 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('storageService', function($rootScope, $q){

			this.get = function(key){
				return $q(function(resolve, reject){
					try {
						chrome.storage.local.get(key, function(obj){
							if(obj&&obj[key]){
								var value = angular.fromJson(obj[key]);
								resolve(value);
							}
							else{
								reject();
							}
						});
					} catch(e){
						console.log(key);
					}
				});
			};

			this.setOnBrowserLocalStorage = function(key, value){
				var obj = {};
				obj[key] = value;
				chrome.storage.local.set(obj);
			};

			this.setOnBrowserLocalStorageToJson = function(key, value){
				var obj = {};
				obj[key] = angular.toJson(value);
				chrome.storage.local.set(obj);
			};

			// local DB에 set하라고 들어온 값을 object로 감싸고, 그 object내에 있는 key값에 들어온 value 파라미터에 있는 값을
			// angular.toJson메서드를 이용해서 넣는다.
			// 그리고 chrome.storage.local에 set한다.
			this.set = function(key, value){
				var self = this;
				try {
					// local DB에 정보를 set하라는 신호를 받았는데 key값이나 value값이 없을 때는 return;
					if(!(angular.isDefined(key)&&angular.isDefined(value))) return;
					chrome.storage.local.get(key, function(obj){
						// 로컬 db에 이미 해당 key값을 가진 grammer_storage가 있을 때
						if(obj&&obj[key]){
							// 새로 세팅하려는 grammer_storage와 기존 grammer_storage가 같을 경우
							if(obj[key]===angular.toJson(value)){
								self.setOnBrowserLocalStorageToJson(key, value);
								// 이미 필요한 내용이 chrome.storage.local에 있기 때문에 따로 저장하지 않는다.
							}
							// 새로 세팅하려는 grammer_storage와 기존 grammer_storage가 다를 경우
							else{
								// chrome.storage.local.set({ key : value }) 형식으로 집어넣는다.
								self.setOnBrowserLocalStorageToJson(key, value);
							}
						}
						// 로컬 db에 이미 해당 key값을 가진 grammer_storage가 없을 때
						else{
							// chrome.storage.local.set({ key : value }) 형식으로 집어넣는다.
							self.setOnBrowserLocalStorageToJson(key, value);
						}
					});
				} catch(e){
					console.log(key);
					console.log(value);
				}
			};
		});


/***/ },
/* 7 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('urlService', function($rootScope, $q){
			this.getCurrentTab = function(){
				return $q(function(resolve, reject){
					chrome.tabs.getSelected(null, function(tab){
						resolve(tab);
					});
				});
			};
			this.getUrl = function(){
				var self = this;
				return $q(function(resolve, reject){
					self.getCurrentTab().then(function(tab){
						resolve(tab.url);
					});
				});
			};
			this.setUrl = function(url){
				var self = this;
				self.getCurrentTab().then(function(tab){
				  chrome.tabs.update(tab.id, {url: url});
				});
			};
		});


/***/ },
/* 8 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('booleanService', function($rootScope, stringService){
			this.makeBoolean = function(boolean){
				if(boolean==true){return true;}
				else if(boolean==false){return false;}
				else if(stringService.containString1InString2WithoutCapital(boolean, 'true')){return true;}
				else if(stringService.containString1InString2WithoutCapital(boolean, 'false')){return false;}
				else return false;
			};
			this.checkBoolean = function(boolean){
				if(boolean==true||boolean==false) { return true; }
				else { return false; }
			};
		});

/***/ },
/* 9 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('getService', function($rootScope, $q){

			this.getNumberingOfElements = function(elements){
				var self = this;
				var numbering_of_elements = new Array(_.size(elements));
				return numbering_of_elements;
			};

		});

/***/ },
/* 10 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('cookieService', function($rootScope, $q){

			this.getCookie = function(cookie_key) {
		    var name = cookie_key + "=";
		    var ca = document.cookie.split(';');
		    for(var i = 0; i <ca.length; i++) {
		        var c = ca[i];
		        while (c.charAt(0)==' ') {
		            c = c.substring(1);
		        }
		        if (c.indexOf(name) == 0) {
		            return c.substring(name.length,c.length);
		        }
		    }
		    return "";
			};

			this.setCookie = function(cookie_key, cookie_value) {
		    document.cookie = cookie_key + "=" + cookie_value + ";";
			};

		});

/***/ },
/* 11 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('grammerOriginalService', function($rootScope){

			// VERSION CHANGE: Must be checked when adding, deleting or changing versions (버전 추가, 삭제, 변경시 필수적으로 체크해야함)

			this.grammers = {

				bandgrammer : {
					id: 1,
			  	description : '밴드그래머',
				  host : ['band.us'],
					url : 'http://band.us',
			  	logo : 'img/logo_bandgrammer.png',
			    versions : {
			    	invite : {
	  			  	id: 1,
		    			description:'초대',
							funcs : {
								invite : { id: 1, icon:'ion-log-in', description : '초대'}
							},
							settings : {
								// WORK
								// interval_work:{ id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:30, recommend:'30 이상' },

								// DELAY
								count_delay : { id: 2, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:3, recommend:'3 이상' },
								perentage_delay : { id: 3, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:30, recommend:'30 이하' },

								// REST
								boolean_rest : { id: 4, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest : { id: 5, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30개 이하' },
								interval_rest : { id: 6, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상' },

								// SPAM
								list_spam : { id: 7, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['점집','학원','대출','햇살론','신용','대출','중고차','업체','원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								}
							}
		    		},
						review : {
	  			  	id: 2,
		    			description:'댓글 관리',
							funcs : {
								like:{ id: 1, icon:'ion-heart', description:'좋아요', logs:[]},
							},
							settings : {
								// WORK
								interval_work:{ id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:60, recommend:'60 이상' },

								// DELAY
								count_delay : { id: 2, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:3, recommend:'3 이상' },
								perentage_delay : { id: 3, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:30, recommend:'30 이하' },

								// REST
								boolean_rest : { id: 4, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest : { id: 5, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30개 이하' },
								interval_rest : { id: 6, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상' },

								// SPAM
								list_spam : { id: 7, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['점집','학원','대출','햇살론','신용','대출','중고차','업체','원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								}
							}
						},
						signup : {
	  			  	id: 3,
		    			description:'가입',
							funcs : {
								signup : { id: 1, icon:'ion-email', description : '가입', ready:false }
							},
							settings : {
							}
						}
		    	}
				},

				blogrammer : {
					id: 2,
			    description : '블로그래머',
			    host : ['blog.naver.com', 'blog.me'],
					url : 'http://section.blog.naver.com',
				  logo : 'img/logo_blogrammer.png',
			    versions : {
		    		newfriend : {
	  			  	id: 1,
		    			description:'이웃 추가',
							funcs:{
								empathize:{ id: 1, icon:'ion-heart', description:'공감', logs:[]},
								review:{ id:2, icon:'ion-chatbubble-working', description:'댓글', logs:[]},
								neighborhood:{ id: 3, icon:'ion-android-contacts', description : '서로이웃추가', logs:[]},
								message:{ id: 4, icon:'ion-paper-airplane', description : '쪽지', logs:[], ready:false }
							},
							settings : {
								// WORK
								interval_search : { id: 1, description:'검색 간격', type:'TIME', question:'몇 초 동안 검색할까요?', default:10, recommend:'10 이상' },
								list_search : { id: 2, description:'검색 태그 목록', type:'ARRAY', question:'어떤 장소 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['영화','미술','디자인','공연','전시','음악','노래','드라마','연예인','만화','일상','생각','육아','결혼','동물','좋은글','패션','미용','요리','게임','야구','축구','학교','공부','자동차','취미','국내','해외','여행','맛집','아침','점심','저녁','직장인','학생']
								},
								interval_work : { id: 3, description:'공감 간격', type:'TIME', question:'몇 초 마다 작업할까요??', default:50, recommend:'50 이상' },
								interval_neighborhood : { id: 5, description:'서로이웃신청 간격', type:'TIME', question:'몇 초 마다 서로이웃신청을 진행할까요?', default:40, recommend:'40 이상' },
								percentage_review : { id: 6, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 댓글을 달고 싶습니까?', default:80, recommend:'80 이하' },
								sticker_review_boolean:{ id: 7, description:'스티커 댓글 작업 여부', type:'BOOLEAN', question:'스티커로 댓글을 다시겠습니까?(true/false)', default:true, recommend:'true' },
								list_reviews : { id: 8, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다', recommend:'5개 이상',
									default:['자주 소통해요! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요!','좋은 글과 사진들이 참 많네요. 소통해요!', '자주 소통해요 우리! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요! 우리~','좋은 글과 사진들이 참 많네요. 자주 소통해요!']
								},
								secret_review : { id: 9, description:'비밀 댓글 여부', type:'BOOLEAN', question:'댓글을 비밀로 작성하시겠습니까?(true/false)', default:false, recommend:'상관 없음' },
								percentage_neighborhood : { id: 10, description:'서로이웃 추가 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 서로이웃 추가 작업을 하고 싶습니까?', default:80, recommend:'80 이하' },
								percentage_message : { id: 11, description:'쪽지 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 쪽지를 보내고 싶습니까?', default:30, recommend:'30 이하' },
								list_friend_messages : { id: 12, description:'이웃 추가 메세지 목록', type:'ARRAY', question:'이웃추가 시 어떤 메시지들을 보내고 싶나요? 쉼표(,)로 구분합니다', recommend:'5개 이상',
									default:['안녕하세요! 이웃하고 싶어요!', '안녕하세요! 우리 이웃할래요?', '이웃하고 싶습니다. 오늘도 좋은 하루되세요!']
								},
								selected_group : { id:18, description:'선택된 그룹', type:'TEXT', question:'어떤 그룹에 이웃추가를 할까요?', placeholder:'이웃추가 작업할 그룹', default:'', recommend:'선택 작성' },
								review_limit : { id: 19, description:'댓글 작업 한계', type:'NUMBER', question:'하루 몇 번의 댓글작업을 하겠습니까?', default:100, recommend:'100 이하(필)' },
								neighborhood_limit : { id: 20, description:'서이추 작업 한계', type:'NUMBER', question:'하루 몇 번의 서이추작업을 하겠습니까?', default:100, recommend:'100 이하(필)' },
								message_limit : { id: 21, description:'쪽지 작업 한계', type:'NUMBER', question:'하루 몇 번의 쪽지작업을 하겠습니까?', default:100, recommend:'100 이하(필)' },

								// REST
								boolean_rest : { id: 13, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest : { id: 14, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30개 이하' },
								interval_rest : { id: 15, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상' },

								// SPAM
								list_spam : { id: 16, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['점집','학원','대출','햇살론','신용','대출','중고차','업체','원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 17, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id_1','id_2','id_3']
								}
							}
		    		},
		    		communication : {
		    			id: 2,
		    			description:'소통',
		    			funcs:{
		    				review:{ id:1, icon:'ion-chatbubble-working', description:'댓글', logs:[] }
		    			},
		    			settings:{
								// WORK
		    				list_reviews : { id: 1, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다', recommend:'5개 이상',
		    					default:['감사합니다','좋은 하루되세요','잘 부탁드립니다','즐거운 하루 되세요~:-)', '행복한 하루 되세요:)']
		    				}
		    			}
		    		}
			    }
				},

				facegrammer: {
					id: 3,
			    description : '페이스그래머',
			    host : ['facebook.com'],
			    url : 'https://www.facebook.com',
				  logo : 'img/logo_facegrammer.png',
			    versions : {
			  		newfriend:{
							id: 1,
			  			description:'새로운친구',
							funcs:{
								friend_add:{ id: 1, icon:'ion-person-add', description : '친구추가', logs:[]}
							},
							settings : {
								// WORK
								interval_search:{ id: 1, description:'검색 간격', type:'TIME', question:'몇 초 동안 검색할까요?', default:30, recommend:'30 이상' },
								list_search:{ id: 2, description:'검색 태그 목록', type:'ARRAY', question:'어떤 장소 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['연애','여자친구','남자친구','여친','남친','사랑','인생','아침','사진','행복','하늘','구름','가요','노래','슬픔','반지','밥','과일','공부','학업','연예','예능','운동','헬스']
								},
								page_list_search_limit:{ id: 3, description:'페이지 게시글 작업 한계 수', type:'NUMBER', question:'페이지 마다 최대 몇 개의 게시글을 작업하고 싶나요?', default:100, recommend:'상관없음' },
								interval_work:{ id: 4, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:80, recommend:'80 이상' },

								// DELAY
								count_delay : { id: 5, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:3, recommend:'3 이상' },
								perentage_delay : { id: 6, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:30, recommend:'30 이하' },

								// REST
								boolean_rest:{ id: 7, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest:{ id: 8, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:10, recommend:'10 이상' },
								interval_rest:{ id: 9, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:30, recommend:'30 이상' },

								// SPAM
								list_spam:{ id: 10, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다',  recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam:{ id: 11, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id1','id2','id3']
								}
							}
			  		},
			  		unfriend:{
							id: 2,
							description:'친구신청취소',
							funcs : {
								unfriend : { id: 1, icon:'ion-heart-broken', description : '친구요청취소', logs:[] }
							},
							settings : {
								// WORK
								interval_work : { id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:45, recommend:'45 이상'},

								// DELAY
								perentage_delay : { id: 2, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:10, recommend:'10 이하' },
								count_delay : { id: 3, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:100, recommend:'100 이상' },

								// REST
								boolean_rest : { id: 4, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest : { id: 5, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이상' },
								interval_rest : { id: 6, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상' }
							}
						},
			  		newsfeed:{
							id: 3,
			  			description:'뉴스피드관리',
							funcs : {
								like : { id: 1, icon:'ion-thumbsup',	description : '좋아요', logs:[]},
								review : { id: 2, icon:'ion-chatbubble-working', decription : '댓글', logs:[], ready:false}
							},
							settings : {
								// WORK
								interval_work : { id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:50, recommend:'50 이상'},

								// REST
								boolean_rest : { id: 2, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest : { id: 3, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이하' },
								interval_rest : { id: 4, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상' },

								// SPAM
								list_spam : { id: 12, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 13, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id_1','id_2','id_3']
								}
							}
			  		},
			  		page:{
							id: 4,
			  			description:'페이지관리',
							funcs : {
								review_like : { id: 1, icon:'ion-thumbsup',	description : '댓글 좋아요', ready:true},
								bulletin_invite : { id: 2, icon:'ion-email', description : '공감한 사람들 초대', ready:true},
								friend_invite : { id: 3, icon:'ion-paper-airplane', description : '친구 초대', ready:true},
								review : { id: 4, icon:'ion-chatbubbles', description : '답글', ready:false}
							},
							settings : {
								// WORK
								interval_work : { id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:20, recommend:'20 이상'},
								interval_prepare : { id: 2, description:'준비 간격', type:'TIME', question:'작업전 몇 초 동안 준비할까요?', default:10, recommend:'10 이상' },
								page_list_search_limit:{ id: 3, description:'페이지 게시글 작업 한계 수', type:'NUMBER', question:'페이지 마다 최대 몇 개의 게시글을 작업하고 싶나요?', default:100, recommend:'상관없음' },

								// DELAY
								count_delay : { id: 4, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:5, recommend:'5 이상' },
								perentage_delay : { id: 5, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:5, recommend:'5 이하' },

								// REST
								boolean_rest:{ id: 6, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest:{ id: 7, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 번의 페이지 작업마다 쉬게 할까요?', default:2, recommend:'2 이상' },
								interval_rest:{ id: 8, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:30, recommend:'30 이상' },

								// SPAM
								list_spam : { id: 9, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 댓글들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다',  recommend:'15개 이상',
									default : ['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 10, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id1','id2','id3']
								}
							}
			  		},
			  		competition:{
							id: 5,
			  			description:'경쟁사',
							funcs : {
								extract :	{ id: 1, icon:'ion-ios-folder', description : '추출', ready:false}
							},
							settings : {
							}
			  		}
			    }
				},

				instagrammer : {
					id: 4,
			    description : '인스타그래머',
			    host : ['instagram.com'],
			    url : 'https://www.instagram.com',
				  logo : 'img/logo_instagrammer.png',
			    versions : {
		    		follow : {
	    			  id: 1,
		    			description:'팔로우',
							funcs:{
								like : { id: 1, icon:'ion-thumbsup', description : '좋아요', logs:[]},
								follow : { id: 2, icon:'ion-heart', description : '팔로우', logs:[]},
								review : { id: 3, icon:'ion-chatbubble-working',	description : '댓글', logs:[]}
							},
							settings : {
								// WORK
								interval_search : { id: 1, description:'검색 간격', type:'TIME', question:'몇 초 동안 검색할까요?', default:20, recommend:'20 이상' },
								list_search : { id: 2, description:'검색 태그 목록', type:'ARRAY', question:'어떤 장소 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['셀스타그램','인스타그램','얼스타그램','맛스타그램','먹스타그램','럽스타그램','데일리룩','다이어트','지름신','데일리','셀기꾼','사진','셀카','셀피','맞팔','인친','선팔','영화','미술','디자인','공연','전시','음악','노래','드라마','연예인','만화','일상','생각','육아','결혼','동물','좋은글','패션','미용','요리','게임','야구','축구','학교','공부','자동차','취미','국내','해외','맛집','아침','점심','저녁','직장인','학생']
								},
								interval_work : { id: 3, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:50, recommend:'50 이상'},
								percentage_like : { id: 4, description:'좋아요 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 좋아요하고 싶습니까?', default:100, recommend:'100 이하' },
								percentage_follow : { id: 5, description:'팔로우 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 팔로우하고 싶습니까?', default:50, recommend:'50 이하' },
								percentage_review : { id: 6, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:50, recommend:'50 이하' },
								list_reviews : { id: 7, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다', recommend:'5개 이상',
									default:['자주 소통해요! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요!','좋은 글과 사진들이 참 많네요. 소통해요!', '자주 소통해요 우리! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요! 우리~','좋은 글과 사진들이 참 많네요. 자주 소통해요!']
								},
								list_reviews_username : { id: 8, description:'이름태그댓글 목록', type:'ARRAY', question:'상대방 사용자 이름에 어떤 말을 붙여서 댓글을 달고 싶나요? 쉼표(,)로 구분합니다.', recommend:'5개 이상',
									default:['님 사진 잘 보고 갑니다.ㅎㅎ', '님 잘 둘러보고 가요~', '님 좋은 사진들 잘 보고 갑니다ㅎㅎ', '님 행복한 하루 되세요ㅎㅎ', '님 사진이 좋네요ㅎㅎ:)']
								},
								boolean_review_username : { id: 9, description:'이름태그댓글 사용여부', type:'BOOLEAN', question:'상대방 유저 이름으로 댓글을 등록하실래요?', default:false, recommend:'상관없음' },

								// REST
								boolean_rest : { id: 10, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음'},
								count_rest : { id: 11, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이상'},
								interval_rest : { id: 12, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상'},

								// SPAM
								list_spam : { id: 13, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 14, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id_1','id_2','id_3']
								}
							}
						},
						follower : {
							id: 2,
							description: '팔로워관리',
							funcs: {
								like: { id: 1, icon:'ion-thumbsup', description : '좋아요', logs:[]},
								review: { id: 2, icon:'ion-chatbubble-working',	description : '댓글', logs:[]}
							},
							settings: {
								// WORK
								interval_work : { id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:75, recommend:'75 이상', condition:{ up:35, down:350 } },
								count_bulletin : { id: 2, description:'유저당 최대 게시물 개수', type:'NUMBER', question:'유저당 몇 개의 게시물에 작업하시고 싶으신가요?', default:3, recommend:'3 이상' },
								percentage_review : { id: 3, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:50, recommend:'50 이하' },
								list_reviews : { id: 4, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다',
									default:['오~ 사진 좋네요 ㅎㅎ','사진이 예뻐요ㅎㅎ','항상 잘 보고 있습니다 ㅎㅎ', '좋은 사진 많이 올려주셔서 감사해요 ㅎㅎ','ㅎㅎ 오 좋아요 사진이!','사진 예쁘네요~ ㅎㅎ']
								},

								// DELAY
								perentage_delay : { id: 6, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:20, recommend:'20 이하' },
								count_delay : { id: 7, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:30, recommend:'30 이상' },

								// REST
								boolean_rest : { id: 8, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음'},
								count_rest : { id: 9, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이상'},
								interval_rest : { id: 10, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상'},

								// SPAM
								list_spam : { id: 11, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 12, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id_1','id_2','id_3']
								}
							}
						},
						following : {
							id: 3,
							description: '팔로잉관리',
							funcs: {
								like: { id: 1, icon:'ion-thumbsup', description : '좋아요', logs:[]},
								review: { id: 2, icon:'ion-chatbubble-working',	description : '댓글', logs:[]}
							},
							settings: {
								// WORK
								interval_work : { id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:75, recommend:'75 이상'},
								count_bulletin : { id: 2, description:'유저당 최대 게시물 개수', type:'NUMBER', question:'유저당 몇 개의 게시물에 작업하시고 싶으신가요?', default:3, recommend:'3 이상' },
								percentage_review : { id: 3, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:50, recommend:'50 이하' },
								list_reviews : { id: 4, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다',
									default:['오~ 사진 좋네요 ㅎㅎ','사진이 예뻐요ㅎㅎ','항상 잘 보고 있습니다 ㅎㅎ', '좋은 사진 많이 올려주셔서 감사해요 ㅎㅎ','ㅎㅎ 오 좋아요 사진이!','사진 예쁘네요~ ㅎㅎ']
								},

								// DELAY
								perentage_delay : { id: 7, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:20, recommend:'20 이하' },
								count_delay : { id: 8, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:30, recommend:'30 이상' },

								// REST
								boolean_rest : { id: 9, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음'},
								count_rest : { id: 10, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이상'},
								interval_rest : { id: 11, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상'},

								// SPAM
								list_spam : { id: 10, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 11, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id_1','id_2','id_3']
								}
							},
						},
						other_follower : {
							id: 4,
							description:'특정유저 팔로워관리',
							funcs : {
								like : { id: 1, icon:'ion-thumbsup', description:'좋아요', logs:[] },
								follow : { id: 2, icon:'ion-heart', description:'팔로우', logs:[] },
								review : { id: 3, icon:'ion-chatbubble-working', description:'댓글', logs:[] }
							},
							settings : {
								// WORK
								interval_work : { id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:75, recommend:'75 이상'},
								list_user_other : { id: 2, description:'계정 목록', type:'ARRAY', question:'어느 계정들에 작업하시겠어요? 쉼표(,)로 구분합니다', recommend:'필수 작성',
									default:['id_1','id_2','id_3'] },
								count_bulletin : { id: 3, description:'유저당 최대 게시물 개수', type:'NUMBER', question:'유저당 몇 개의 게시물에 작업하시고 싶으신가요?', default:3, recommend:'3 이상' },
								percentage_follow : { id: 4, description:'팔로우 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 팔로우하고 싶습니까?', default:75, recommend:'75 이하' },
								percentage_review : { id: 5, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:50, recommend:'50 이하' },
								list_reviews : { id: 6, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다', recommend:'5개 이상',
									default:['자주 소통해요! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요!','좋은 글과 사진들이 참 많네요. 소통해요!', '자주 소통해요 우리! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요! 우리~','좋은 글과 사진들이 참 많네요. 자주 소통해요!']
								},

								// DELAY
								perentage_delay : { id: 7, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:20, recommend:'20 이하' },
								count_delay : { id: 8, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:30, recommend:'30 이상' },

								// REST
								boolean_rest : { id: 9, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음'},
								count_rest : { id: 10, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이상'},
								interval_rest : { id: 11, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상'},

								// SPAM
								list_spam : { id: 10, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 11, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id_1','id_2','id_3']
								}
							}
						},
						other_following : {
							id: 5,
							description:'특정유저 팔로잉관리',
							funcs : {
								like : { id: 1, icon:'ion-thumbsup', description:'좋아요', logs:[] },
								follow : { id: 2, icon:'ion-heart', description:'팔로우', logs:[] },
								review : { id: 3, icon:'ion-chatbubble-working', description:'댓글', logs:[] }
							},
							settings : {
								// WORK
								interval_work : { id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:75, recommend:'75 이상'},
								list_user_other : { id: 2, description:'계정 목록', type:'ARRAY', question:'어느 계정들에 작업하시겠어요? 쉼표(,)로 구분합니다', recommend:'필수 작성',
									default:['id_1','id_2','id_3'] },
								count_bulletin : { id: 3, description:'유저당 최대 게시물 개수', type:'NUMBER', question:'유저당 몇 개의 게시물에 작업하시고 싶으신가요?', default:3, recommend:'3 이상' },
								percentage_follow : { id: 4, description:'팔로우 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 팔로우하고 싶습니까?', default:75, recommend:'75 이하' },
								percentage_review : { id: 5, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:50, recommend:'50 이하' },
								list_reviews : { id: 6, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다', recommend:'5개 이상',
									default:['자주 소통해요! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요!','좋은 글과 사진들이 참 많네요. 소통해요!', '자주 소통해요 우리! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요! 우리~','좋은 글과 사진들이 참 많네요. 자주 소통해요!']
								},

								// DELAY
								perentage_delay : { id: 7, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:20, recommend:'20 이하' },
								count_delay : { id: 8, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:30, recommend:'30 이상' },

								// REST
								boolean_rest : { id: 9, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음'},
								count_rest : { id: 10, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이상'},
								interval_rest : { id: 11, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상'},

								// SPAM
								list_spam : { id: 10, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 11, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id_1','id_2','id_3']
								}
							}
						},
						unfollow : {
							id: 6,
							description:'언팔로우',
							funcs : {
								unfollow : { id: 1, icon:'ion-heart-broken', image_url:'img/unfollow.png',	description : '맞팔제외 언팔', only: true, logs:[] },
								unfollow_all : { id: 2, image_url:'img/unfollow_all.png', description : '모두 언팔', only: true, logs:[] }
							},
							settings : {
								// WORK
								list_user_prohibited : { id: 1, description:'작업 금지 유저목록', type:'ARRAY', question:'어떤 사람들을 작업하지 말까요?',
									default:['id1', 'id2', 'id3']
								},

								// DELAY
								perentage_delay : { id: 2, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:20, recommend:'20 이하' },
								count_delay : { id: 3, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:30, recommend:'30 이상' },

								// REST
								boolean_rest : { id: 4, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest : { id: 5, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:100, recommend:'100 이하' },
								interval_rest : { id: 6, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:1, recommend:'1 이상' }
							}
						},
						switch : {
							id: 7,
							description: '자동조절',
							funcs: {
								like : { id: 1, icon:'ion-thumbsup', description : '좋아요', logs:[]},
								follow : { id: 2, icon:'ion-heart', description : '팔로우', logs:[]},
								review : { id: 3, icon:'ion-chatbubble-working',	description : '댓글', logs:[]},
								unfollow : { id: 4, icon:'ion-heart-broken', image_url:'img/unfollow.png',	description : '맞팔제외 언팔', only: true, logs:[] },
								unfollow_all : { id: 5, image_url:'img/unfollow_all.png', description : '모두언팔', only: true, logs:[] }
							},
							is_btob: true,
							settings: {
								// SWITCH
								count_switch : { id: 1, description:'버전변경 팔로잉 수', essential_on_btob:true, type:'NUMBER', question:'팔로잉 몇을 기준으로 버전변경(팔로우<->언팔로우)할까요?', default:7000, recommend:'7500 이하' },
								boolean_upload : { id: 2, description:'게시물 자동 업로드 여부', essential_on_btob:true, type:'BOOLEAN', question:'그래머웹에 올린 해당 계정에 해당하는 게시물을 자동 업로드할까요?', default:false, recommend:'상관없음' },
								time_upload : { id: 3, description:'게시물 업로드 시간대(24시 기준)', essential_on_btob:true, type:'NUMBER', question:'업로드할 시간대가 어떻게 되나요?', default:20, recommend:'상관없음' },

								// UNFOLLOW
								password : { id: 4, description:'계정 비밀번호', essential_on_btob:true, type:'TEXT', question:'언팔로우에 사용할 계정의 비밀번호는 어떻게 되나요? 올바르게 입력해주세요', placeholder:'계정 비밀번호', default:'', recommend:'필수 입력' },

								// FOLLOW SEARCH
								interval_search : { id: 5, description:'검색 간격', type:'TIME', question:'몇 초 동안 검색할까요?', default:20, recommend:'20 이상' },
								list_search : { id: 6, description:'검색 태그 목록', essential_on_btob:true, type:'ARRAY', question:'어떤 장소 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['셀스타그램','인스타그램','얼스타그램','맛스타그램','먹스타그램','럽스타그램','데일리룩','다이어트','지름신','데일리','셀기꾼','사진','셀카','셀피','맞팔','인친','선팔','영화','미술','디자인','공연','전시','음악','노래','드라마','연예인','만화','일상','생각','육아','결혼','동물','좋은글','패션','미용','요리','게임','야구','축구','학교','공부','자동차','취미','국내','해외','맛집','아침','점심','저녁','직장인','학생']
								},

								// FOLLOW WORK
								interval_work : { id: 7, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:50, recommend:'50 이상'},
								percentage_like : { id: 8, description:'좋아요 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 좋아요하고 싶습니까?', default:100, recommend:'100 이하' },
								percentage_follow : { id: 9, description:'팔로우 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 팔로우하고 싶습니까?', default:50, recommend:'50 이하' },
								percentage_review : { id: 10, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:50, recommend:'50 이하' },
								list_reviews : { id: 11, description:'댓글 목록', essential_on_btob:true, type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다', recommend:'5개 이상',
									default:['자주 소통해요! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요!','좋은 글과 사진들이 참 많네요. 소통해요!', '자주 소통해요 우리! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요! 우리~','좋은 글과 사진들이 참 많네요. 자주 소통해요!']
								},
								list_reviews_username : { id: 12, description:'이름태그댓글 목록', type:'ARRAY', question:'상대방 사용자 이름에 어떤 말을 붙여서 댓글을 달고 싶나요? 쉼표(,)로 구분합니다.', recommend:'5개 이상',
									default:['님 사진 잘 보고 갑니다.ㅎㅎ', '님 잘 둘러보고 가요~', '님 좋은 사진들 잘 보고 갑니다ㅎㅎ', '님 행복한 하루 되세요ㅎㅎ', '님 사진이 좋네요ㅎㅎ:)']
								},
								boolean_review_username : { id: 13, description:'이름태그댓글 사용여부', type:'BOOLEAN', question:'상대방 유저 이름으로 댓글을 등록하실래요?', default:false, recommend:'상관없음' },

								// DELAY
								perentage_delay : { id: 21, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:20, recommend:'20 이하' },
								count_delay : { id: 22, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:30, recommend:'30 이상' },

								// SPAM
								list_spam : { id: 17, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 18, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id_1','id_2','id_3']
								},

								// REST
								boolean_rest : { id: 14, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음'},
								count_rest : { id: 15, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이상'},
								interval_rest : { id: 16, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상'},

								list_user_prohibited : { id: 20, description:'작업 금지 유저목록', type:'ARRAY', question:'어떤 사람들을 작업하지 말까요?',
									default:['id1', 'id2', 'id3']
								},

							}
						}
			    }
				},

				kakaogrammer: {
					id: 5,
			    description : '카카오그래머',
			    host : ['story.kakao.com'],
			    host_not : ['story.kakao.com/ch', 'ch.kakao.com'],
			    url : 'https://story.kakao.com',
				  logo : 'img/logo_kakaogrammer.png',
			    versions : {
		    		newfriend : {
	  			  	id: 1,
		    			description:'새로운 친구',
							funcs:{
								like : { id: 1, icon:'ion-thumbsup',	description : '좋아요', logs:[]},
								friend : { id: 2, icon:'ion-person-add',	description : '친구추가', logs:[]},
								review : { id: 3, icon:'ion-chatbubble-working',	description : '댓글', logs:[]}
							},
							settings : {
								// WORK
								interval_search : { id: 1, description:'검색 간격', type:'TIME', question:'몇 초 동안 검색할까요?', default:50, recommend:'50 이상'},
								list_search : { id: 2, description:'검색 태그 목록', type:'ARRAY', question:'어떤 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['영화','미술','디자인','공연','전시','음악','노래','드라마','연예인','만화','일상','생각','육아','결혼','동물','좋은글','패션','미용','요리','게임','야구','축구','학교','공부','자동차','취미','국내','해외','여행','맛집','아침','점심','저녁','직장인','학생']
								},
								interval_work : { id: 3, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:90, recommend:'90 이상' },
								percentage_friend : { id: 4, description:'친구 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 친구 추가하고 싶습니까?', default:50, recommend:'50 이하' },
								percentage_review : { id: 5, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:30, recommend:'30 이하' },
								list_reviews : { id: 6, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다',
									default:['자주 소통해요! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요!','좋은 글과 사진들이 참 많네요. 소통해요!', '자주 소통해요 우리! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요! 우리~','좋은 글과 사진들이 참 많네요. 자주 소통해요!']
								},
								friend_limit_value : { id: 7, description:'친구추가 작업 한계', type:'NUMBER', question:'하루 몇 번의 친구추가를 하겠습니까?', default:10, recommend:'10 이하(필)' },
								work_time_limit : { id: 8, description:'작업 시간 한계', type:'TIME', question:'한번 작업시 몇 시간을 구동하시겠습니까?', default:10, recommend:'상관없음' },
								kakao_friend_apply_limit: { id: 9, description:'카카오 친구신청 제한 수', type:'NUMBER', question:'카카오 친구신청 제한을 몇으로 설정하시겠습니까?', default:200, recommend:'상관없음' },

								// REST
								boolean_rest : { id: 10, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest : { id: 11, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:20, recommend:'20 이하' },
								interval_rest : { id: 12, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:120, recommend:'120 이상' },

								// SPAM
								list_spam : { id: 13, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 14, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다', default:['id1','id2','id3'] }
							}
		    		},
		    		unfriend : {
	  			  	id: 2,
		    			description:'친구신청 취소',
							funcs : {
								unfriend : { id: 1, icon:'ion-heart-broken', description: '친구요청 취소' }
							},
							settings : {
								// WORK
								interval_work : { id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:45, recommend:'45 이상'},

								// DELAY
								perentage_delay : { id: 2, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:10, recommend:'10 이하' },
								count_delay : { id: 3, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:5, recommend:'5 이상' },

								// REST
								boolean_rest : { id: 4, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest : { id: 5, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이상' },
								interval_rest : { id: 6, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상' }
							}
		    		}
			    }
				},

				kakaogrammer_channel:{
					id: 6,
					description:'카카오그래머 (채널)',
					host : ['story.kakao.com', 'story.kakao.com/ch', 'ch.kakao.com'],
					// html:{ tag:'a', classes:{list:['link_tit', '_nameHolder']}, href:'/ch' },
					url : 'https://ch.kakao.com/channels',
					logo : 'img/logo_kakaochannelgrammer.png',
					versions : {
						invite : {
							id: 1,
							description:'초대',
							funcs : {
								invite : { id: 1, icon:'ion-paper-airplane', description : '친구 초대', ready:true}
							},
							settings : {
								// WORK
								list_channels : { id: 1, description:'작업할 채널 목록', type:'ARRAY', question:'어느 채널들에 작업하시겠어요? 쉼표(,)로 구분합니다', recommend:'상관없음',
									default:['https://story.kakao.com/ch/snsgrammer', 'https://story.kakao.com/ch/grammer_black']
								},
								interval_work : { id: 2, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:20, recommend:'20 이상'},

								// DELAY
								count_delay : { id: 3, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:10, recommend:'10 이상' },
								perentage_delay : { id: 4, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:5, recommend:'5 이하' },

								// REST
								boolean_rest:{ id: 5, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest:{ id: 6, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 번의 페이지 작업마다 쉬게 할까요?', default:2, recommend:'2 이상' },
								interval_rest:{ id: 7, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:30, recommend:'30 이상' },

								// SPAM
								list_user_spam : { id: 8, description:'스팸성 유저 목록', type:'ARRAY', question:'초대하면 안되는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id1','id2','id3']
								}
							}
						},
						review : {
							id: 2,
							description:'댓글 관리',
							funcs : {
								like : { id: 1, icon:'ion-thumbsup',	description : '댓글 좋아요', ready:true}
							},
							settings : {
								// WORK
								interval_work : { id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:50, recommend:'50 이상'},

								// DELAY
								count_delay : { id: 2, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:10, recommend:'10 이상' },
								perentage_delay : { id: 3, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:5, recommend:'5 이하' },

								// REST
								boolean_rest:{ id: 4, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest:{ id: 5, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 번의 페이지 작업마다 쉬게 할까요?', default:2, recommend:'2 이상' },
								interval_rest:{ id: 6, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:30, recommend:'30 이상' },

								// SPAM
								list_spam : { id: 7, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 댓글들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다',  recommend:'15개 이상',
									default : ['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 8, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 댓글을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id1','id2','id3']
								}
							}
						}
					}
				},

				pholagrammer : {
					id: 7,
			    description : '폴라그래머',
			    host : ['pholar.co'],
					url : 'http://www.pholar.co',
				  logo : 'img/logo_pholagrammer.png',
			    versions : {
			    	follow:{
	  			  	id: 1,
							description:'팔로우',
							funcs : {
								like : { id: 1, icon:'ion-thumbsup',	description : '좋아요', logs:[] },
								follow : { id: 2, icon:'ion-heart', description : '팔로우', logs:[] },
								review : { id: 3, icon:'ion-chatbubble-working',	description : '댓글', logs:[] }
							},
							settings : {
								// WORK
								interval_search:{ id: 1, description:'검색 간격', type:'TIME', question:'몇 초 동안 검색할까요?', default:30, recommend:'30 이상' },
								list_search:{ id: 2, description:'검색 태그 목록', type:'ARRAY', question:'어떤 장소 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['영화','미술','디자인','공연','전시','음악','노래','드라마','연예인','만화','일상','생각','육아','결혼','동물','좋은글','패션','미용','요리','게임','야구','축구','학교','공부','자동차','취미','국내','해외','여행','맛집','아침','점심','저녁','직장인','학생']
								},
								interval_work:{ id: 3, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:60, recommend:'60 이상' },
								percentage_follow:{ id: 4, description:'팔로우 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 팔로우하고 싶습니까?', default:30, recommend:'30 이하' },
								percentage_review:{ id: 5, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:30, recommend:'30 이하' },
								list_reviews:{ id: 6, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다',
									default:['자주 소통해요! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요!','좋은 글과 사진들이 참 많네요. 소통해요!', '자주 소통해요 우리! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요! 우리~','좋은 글과 사진들이 참 많네요. 자주 소통해요!']
								},

								// REST
								boolean_rest:{ id: 7, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest:{ id: 8, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이하' },
								interval_rest:{ id: 9, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상' },

								// SPAM
								list_spam:{ id: 10, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam:{ id: 11, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다', default:['id1','id2','id3'] }
			    		}
			    	},
		    		unfollow:{
	  			  	id: 2,
							description:'언팔로우',
							funcs : {
								unfollow:{ id: 1, icon:'ion-heart-broken', description : '언팔로우', logs:[]}
							},
							settings : {
								// WORK
								interval_work:{ id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:35, recommend:'35 이상' },

								// REST
								boolean_rest:{ id: 2, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest:{ id: 3, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이하' },
								interval_rest:{ id: 4, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상' },

								// DELAY
								perentage_delay : { id: 5, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:20, recommend:'20 이하' },
								count_delay : { id: 6, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:30, recommend:'30 이상' }
							}
						}
			    }
				},

				postgrammer:{
					id: 8,
					description:'포스트그래머',
					host : ['post.naver.com'],
					url : 'http://post.naver.com/',
					logo : 'img/logo_postgrammer.png',
					versions : {
						follow:{
							id: 1,
							description:'팔로우',
							funcs : {
								like : { id: 1, icon:'ion-thumbsup', description : '좋아요', logs:[]},
								follow : { id: 2, icon:'ion-heart', description : '팔로우', logs:[]},
								review : { id: 3, icon:'ion-chatbubble-working',	description : '댓글', logs:[]}
							},
							settings : {
								// WORK
								interval_search:{ id: 1, description:'검색 간격', type:'TIME', question:'몇 초 동안 검색할까요?', default:30, recommend:'30 이상' },
								list_search:{ id: 2, description:'검색 태그 목록', type:'ARRAY', question:'어떤 장소 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['영화','미술','디자인','공연','전시','음악','노래','드라마','연예인','만화','일상','생각','육아','결혼','동물','좋은글','패션','미용','요리','게임','야구','축구','학교','공부','자동차','취미','국내','해외','여행','맛집','아침','점심','저녁','직장인','학생']
								},
								list_reviews:{ id: 3, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 달고 싶으신가요? 쉼표(,)로 구분합니다.', recommend:'10개 이상',
									default:['음.. 많은 걸 느끼고 갑니다~', '좋은 정보 잘 보고 가네용', '유익하네요~ 선팔하고 갑니다 ㅎㅎ', '좋은 정보 감사합니다~~', '선팔하고 갈게요~! 맞팔와주세요 ㅎㅎ']
								},
								sticker_review_boolean:{ id: 4, description:'스티커 댓글 작업 여부', type:'BOOLEAN', question:'스티커로 댓글을 다시겠습니까?(true/false)', default:true, recommend:'true' },
								interval_work:{ id: 5, description:'작업 간격',type:'TIME', question:'몇 초 마다 작업할까요?', default:40, recommend:'40 이상' },
								percentage_follow:{ id: 6, description:'팔로우 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 팔로우를 하고 싶습니까?', default:60, recommend:'60 이하' },
								percentage_review:{ id: 7, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:60, recommend:'60 이하' },

								// LIMIT
								like_limit:{ id: 8, description:'좋아요 작업 한계', type:'NUMBER', question:'하루 몇 번의 좋아요를 하겠습니까?', default:2000, recommend:'상관없음' },
								follow_limit:{ id: 9, description:'팔로우 작업 한계', type:'NUMBER', question:'하루 몇 번의 팔로우를 하겠습니까?', default:100, recommend:'100 이하(필)' },
								review_limit:{ id: 10, description:'댓글 작업 한계', type:'NUMBER', question:'하루 몇 번의 댓글을 하겠습니까?', default:100, recommend:'100 이하(필)' },

								// REST
								boolean_rest:{ id: 13, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest:{ id: 14, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이하' },
								interval_rest:{ id: 15, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:60, recommend:'60 이상' },

								// SPAM
								list_spam : { id: 11, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다', recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam : { id: 12, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다',
									default:['id_1','id_2','id_3']
								}
							}
						},
						unfollow:{
							id: 2,
							description:'언팔로우',
							funcs : {
								unfollow : { id: 1, icon:'ion-heart-broken', description : '언팔로우', logs:[]}
							},
							settings : {
								// WORK
								list_user_prohibited : { id: 1, description:'작업 금지 유저목록', type:'ARRAY', question:'어떤 사람들을 작업하지 말까요?',
									default:['id1', 'id2', 'id3']
								},
								interval_work:{ id: 2, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:35, recommend:'35 이상' },

								// REST
								boolean_rest:{ id: 3, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest:{ id: 4, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이하' },
								interval_rest:{ id: 5, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상' },

								// DELAY
								perentage_delay : { id: 6, description:'지연 퍼센트', type:'TIME', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:20, recommend:'20 이하' },
								count_delay : { id: 7, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:5, recommend:'5 이상' }
							}
						},
						invite:{
							id: 3,
							description:'초대',
							funcs : {
								invite : { id: 1, icon:'ion-email', description : '초대', logs:[], ready:false }
							},
							settings : {
								// SEARCH
								interval_search:{ id: 1, description:'검색 간격', type:'TIME', question:'몇 초 동안 검색할까요?', default:20, recommend:'20 이상' },
								list_search:{ id: 2, description:'검색 태그 목록', type:'ARRAY', question:'어떤 장소 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다',  recommend:'15개 이상',
									default:['영화','미술','디자인','공연','전시','음악','노래','드라마','연예인','만화','일상','생각','육아','결혼','동물','좋은글','패션','미용','요리','게임','야구','축구','학교','공부','자동차','취미','국내','해외','여행','맛집','아침','점심','저녁','직장인','학생']
								},

								// WORK
								interval_work:{ id: 3, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:10, recommend:'10 이상' },
								daily_invite:{ id: 4, description:'하루 스크랩 수', type:'NUMBER', question:'하루 몇 번의 스크랩을 할까요?', default:100, recommend:'100(고정)' }
							}
						}
					}
				},

				twitgrammer:{
					id: 9,
			    description : '트위터그래머',
			    host : ['twitter.com'],
					url : 'https://twitter.com',
				  logo : 'img/logo_twitgrammer.png',
			    versions : {
			    	follow:{
	  			  	id: 1,
							description:'팔로우',
							funcs : {
								like : { id: 1, icon:'ion-thumbsup',	description:'좋아요', logs:[]},
								follow : { id: 2, icon:'ion-heart', description:'팔로우', logs:[]},
								review : { id: 3, icon:'ion-chatbubble-working',	description:'트윗', logs:[]}
							},
							settings : {
								// WORK
								list_search:{ id: 1, description:'검색 태그 목록', type:'ARRAY', question:'어떤 장소 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다',  recommend:'15개 이상',
									default:['영화','미술','디자인','공연','전시','음악','노래','드라마','연예인','만화','일상','생각','육아','결혼','동물','좋은글','패션','미용','요리','게임','야구','축구','학교','공부','자동차','취미','국내','해외','여행','맛집','아침','점심','저녁','직장인','학생','사람','소통','축제','사랑','마음','구름','강아지','말','반려견','반려묘','예쁨','수작업','즐거움','일상생활','너와나','여행','해외']
								},
								interval_work:{ id: 2, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:150, recommend:'150 이상' },
								percentage_follow:{ id: 3, description:'팔로우 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 팔로우하고 싶습니까?', default:20, recommend:'20 이하' },
								percentage_review:{ id: 4, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:20, recommend:'20 이하' },
								list_reviews:{ id: 5, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다', default:['자주 소통해요! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요!','좋은 글과 사진들이 참 많네요. 소통해요!', '자주 소통해요 우리! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요! 우리~','좋은 글과 사진들이 참 많네요. 자주 소통해요!'] },

								// REST
								boolean_rest:{ id: 6, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:true, recommend:'true' },
								count_rest:{ id: 7, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:15, recommend:'15 이하' },
								interval_rest:{ id: 8, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:60, recommend:'60 이상' },

								// SPAM
								list_spam:{ id: 9, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다',  recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam:{ id: 10, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다', default:['id1','id2','id3']}
							}
			  		},
		    		unfollow:{
	  			  	id: 2,
							description:'언팔로우',
							funcs : {
								unfollow : { id: 1, icon:'ion-heart-broken', description:'언팔로우', logs:[]}
							},
							settings : {
								// WORK
								interval_work:{ id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:45, recommend:'45 이상' },

								// DELAY
								perentage_delay : { id: 2, description:'지연 퍼센트', type:'PERCENTAGE', question:'작업이 지연될 때 몇 퍼센트 정도 차이가 났을 때 넘어갈까요?', default:20, recommend:'20 이하' },
								count_delay : { id: 3, description:'지연 횟수', type:'TIME', question:'작업이 지연될 때 몇 번 동안 확인하고 넘어갈까요?', default:300, recommend:'300 이상' },

								// REST
								boolean_rest:{ id: 2, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음' },
								count_rest:{ id: 3, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이상' },
								interval_rest:{ id: 4, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상' }
							}
						}
			    }
				},

				vingrammer:{
					id: 10,
				  description:'빙글그래머',
				  host : ['vingle.net'],
					url : 'https://www.vingle.net',
				  logo : 'img/logo_vingrammer.png',
				  versions : {
				  	follow:{
	  			  	id: 1,
							description:'팔로우',
							funcs : {
								like : { id: 1, icon:'ion-thumbsup', description:'좋아요', logs:[]},
								follow : { id: 2, icon:'ion-heart', description:'팔로우', logs:[]},
								review : { id: 3, icon:'ion-chatbubble-working', description:'댓글', logs:[]}
							},
							settings : {
								// WORK
								list_search:{ id: 1, description:'검색 태그 목록', type:'ARRAY', question:'어떤 장소 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다',  recommend:'15개 이상',
									default:['영화','미술','디자인','공연','전시','음악','노래','드라마','연예인','만화','일상','생각','육아','결혼','동물','좋은글','패션','미용','요리','게임','야구','축구','학교','공부','자동차','취미','국내','해외','여행','맛집','아침','점심','저녁','직장인','학생','사람','소통','축제','사랑','마음','구름','강아지','말','반려견','반려묘','예쁨','수작업','즐거움','일상생활','너와나','여행','해외']
								},
								interval_search:{ id: 2, description:'검색 간격', type:'TIME', question:'몇 초 동안 검색할까요?', default:20, recommend:'20 이상'},
								interval_work:{ id: 3, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:60, recommend:'60 이상'},
								interval_review:{ id: 4, description:'댓글 작업 간격', type:'TIME', question:'몇 초 마다 리뷰를 진행할까요?', default:15, recommend:'15 이상' },
								percentage_follow:{ id: 5, description:'팔로우 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 팔로우하고 싶습니까?', default:50, recommend:'50 이하'},
								percentage_review:{ id: 6, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:50, recommend:'50 이하'},
								list_reviews:{ id: 7, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다', default:['자주 소통해요! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요!','좋은 글과 사진들이 참 많네요. 소통해요!', '자주 소통해요 우리! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요! 우리~','좋은 글과 사진들이 참 많네요. 자주 소통해요!']},

								// REST
								boolean_rest:{ id: 8, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음'},
								count_rest:{ id: 9, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이하'},
								interval_rest:{ id: 10, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상'},

								// SPAM
								list_spam:{ id: 11, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다',  recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam:{ id: 12, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다', default:['id1','id2','id3'] }
							}
						}
				  }
				},

				weibogrammer:{
					id: 11,
					description:'웨이보그래머',
					host : ['weibo.com'],
					url : 'http://overseas.weibo.com/',
					logo : 'img/logo_weibogrammer.png',
					versions : {

					}
				},

				youtugrammer:{
					id: 12,
				  description:'유투그래머',
					host : ['youtube.com'],
					url : 'https://www.youtube.com',
				  logo : 'img/logo_youtugrammer.png',
				  versions : {
				  	follow:{
	  			  	id: 1,
							description:'팔로우',
							funcs : {
								like:{ id: 1, icon:'ion-thumbsup', description:'좋아요', logs:[]},
								follow:{ id: 2, icon:'ion-heart', description:'구독', logs:[]},
								review:{ id: 3, icon:'ion-chatbubble-working', description:'댓글', logs:[], ready:false}
							},
							settings : {
								// WORK
								interval_search:{ id: 1, description:'검색 간격', type:'TIME', question:'몇 초 동안 검색할까요?', default:30, recommend:'30 이상'},
								list_search:{ id: 2, description:'검색 태그 목록', type:'ARRAY', question:'어떤 장소 단어들을 기준으로 검색하고 싶으신가요? 쉼표(,)로 구분합니다',  recommend:'15개 이상',
									default:['영화','미술','디자인','공연','전시','음악','노래','드라마','연예인','만화','일상','생각','육아','결혼','동물','좋은글','패션','미용','요리','게임','야구','축구','학교','공부','자동차','취미','국내','해외','여행','맛집','아침','점심','저녁','직장인','학생']
								},
								interval_work:{ id: 3, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:60, recommend:'60 이상'},
								percentage_follow:{ id: 4, description:'구독 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 구독하고 싶습니까?', default:30, recommend:'30 이하'},
								percentage_review:{ id: 5, description:'댓글 확률', type:'PERCENTAGE', question:'몇 퍼센트의 확률로 게시물에 댓글을 달고 싶습니까?', default:30, recommend:'30 이하'},
								list_reviews:{ id: 6, description:'댓글 목록', type:'ARRAY', question:'어떤 댓글들을 게시물에 달고 싶나요? 쉼표(,)로 구분합니다', default:['자주 소통해요! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요!','좋은 글과 사진들이 참 많네요. 소통해요!', '자주 소통해요 우리! 오늘도 즐거운 하루 보내세요','사진이 너무 예쁘네요! 소통해요! 우리~','좋은 글과 사진들이 참 많네요. 자주 소통해요!']},

								// REST
								boolean_rest:{ id: 7, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false, recommend:'상관없음'},
								count_rest:{ id: 8, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30, recommend:'30 이하'},
								interval_rest:{ id: 9, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10, recommend:'10 이상'},

								// SPAM
								list_spam:{ id: 10, description:'스팸 목록', type:'ARRAY', question:'어떤 단어가 들어간 게시물들을 건너뛰고 싶나요? 쉼표(,)로 구분합니다',  recommend:'15개 이상',
									default:['원나잇','섹스타그램','sex','섹시','비키니','토토','유부녀','대행','성인놀이터','야스타','바카라','카지노','도박','야동','섹파','가슴','신음','섹','섹코드','색스타그램','색스타','야짤','아우디녀','섹택','폰색','섹톡','야톡','일탈계정','오프남','섹택','브라','섻','vape','호스트','도우미','여성전용','호빠','조건만남','오피걸','섹그램','번개','섻그램','일탈녀','일탈남','야스타','야스타그램','야그램','섹꼬드','만남그램','섻코드','오프녀','오프','디엠','섹스','노출','인증녀','직캠','일탈중','섹파','일탈그램','신음소리','섹텍','폰섹']
								},
								list_user_spam:{ id: 11, description:'스팸성 유저 목록', type:'ARRAY', question:'스팸성 게시물을 올리는 유저들이 누구인가요? 쉼표(,)로 구분합니다', default:['id1','id2','id3'] }
							}
			  		},
			  		unfollow:{
	  			  	id: 2,
							description:'언팔로우',
							funcs : {
								unfollow:{ id: 1, icon:'ion-heart-broken', description:'언팔로우', logs:[]}
							},
							settings : {
								// WORK
								interval_work:{ id: 1, description:'작업 간격', type:'TIME', question:'몇 초 마다 작업할까요?', default:60},

								// REST
								boolean_rest:{ id: 2, description:'쉼 여부', type:'BOOLEAN', question:'사람처럼 쉬기 위해 작업 중간에 쉬게 할까요?', default:false},
								count_rest:{ id: 3, description:'쉼 개수', type:'NUMBER', question:'사람처럼 쉬기 위해 몇 개의 게시물마다 쉬게 할까요?', default:30},
								interval_rest:{ id: 4, description:'쉼 간격', type:'TIME', type_two:'MINUTE', question:'사람처럼 쉬기 위해 몇 분 동안 쉴까요?', default:10}
							}
						}
				  }
				}

			};
		});


/***/ },
/* 12 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('grammerGetService', function($rootScope, $q, storageService, urlService, getService, grammerInitializeService){

			this.getGrammerStorage = function(){
				return $q(function(resolve, reject){
					storageService.get('grammer_storage').then(function(grammer_storage){
						resolve(grammer_storage);
					}, function(){
						grammerInitializeService.initializeGrammerStorage().then(function(grammer_storage){
							resolve(grammer_storage);
						},function(){
							reject();
						});
					});
				});
			};

			this.getGrammers = function(){
				var self = this;
				return $q(function(resolve, reject){
					self.getGrammerStorage().then(function(grammer_storage){
						if(!grammer_storage.grammers){ reject(); return; }
						resolve(grammer_storage.grammers);
					}, function(){
						reject();
					});
				});
			};

			this.getGrammer = function(grammer_key){
				var self = this;
				return $q(function(resolve, reject){
					self.getGrammers().then(function(grammers){
						if(!grammers[grammer_key]){ reject(); return; }
						resolve(grammers[grammer_key]);
					}, function(){
						reject();
					});
				});
			};

			this.getGrammerKeyWithUrl = function(){
				var self = this;
				return $q(function(resolve, reject){
					urlService.getUrl().then(function(url){
						self.getGrammers().then(function(grammers){
							var grammer_index = 0;
							angular.forEach(grammers, function(grammer_value, grammer_key){
								grammer_index += 1;
								var check_host = false;
								var check_host_not = false;
								var check_html = true;

								// Set check_host true or false
								if(grammer_value.host && angular.isArray(grammer_value.host) && grammer_value.host.length>=1 ){
									for(var i=0; i<grammer_value.host.length; i++){
										var host = grammer_value.host[i];
										if(_.includes(url, host)){
											check_host = true;
											break;
										} else{
											check_host = false;
										}
									}
								} else{
									check_host = true;
								}

								// Set check_host_not true or false
								if(grammer_value.host_not && angular.isArray(grammer_value.host_not) && grammer_value.host_not.length>=1 ){
									for(var i=0; i<grammer_value.host_not.length; i++){
										var host_not = grammer_value.host_not[i];
										if(_.includes(url, host_not)){
											check_host_not = false;
											break;
										} else{
											check_host_not = true;
										}
									}
								} else{
									check_host_not = true;
								}

								// Resolve
								if(check_host&&check_host_not){
									resolve(grammer_key);
									return;
								}

								// Reject
								if(grammer_index==_.size(grammers)){ reject(); return; }
							});
						});
					},function(){
						reject();
					});
				});
			};

			this.getVersions = function(grammer_key){
				var self = this;
				return $q(function(resolve, reject){
					self.getGrammer(grammer_key).then(function(grammer_value){
						if(!grammer_value.versions){ reject(); return; }
						resolve(grammer_value.versions);
					}, function(){
						reject();
					});
				});
			};

			this.getVersion = function(grammer_key, version_key){
				var self = this;
				return $q(function(resolve, reject){
					self.getVersions(grammer_key).then(function(versions){
						if(!versions[version_key]){ reject(); return; }
						resolve(versions[version_key]);
					}, function(){
						reject();
					});
				});
			};

			this.getSettings = function(grammer_key, version_key){
				var self = this;
				return $q(function(resolve, reject){
					self.getVersion(grammer_key, version_key).then(function(version){
						if(!version.settings){ reject(); return; }
						resolve(version.settings);
					}, function(){
						reject();
					});
				});
			};

		});


/***/ },
/* 13 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('grammerCheckService', function($rootScope, $q, stringService){
			
			this.checkCurrentFuncKeyOfGrammerStorage = function(grammer_storage){
				var self = this;
				return $q(function(resolve, reject){
					if(grammer_storage&&grammer_storage.current_func_key&&(_.size(grammer_storage.current_func_key)>=1)){ resolve(); }
					else{ reject(); }
				});
			};
			
			this.checkVersionOfGrammerStorage = function(grammer_storage){
				var self = this;
				return $q(function(resolve, reject){
					if(grammer_storage&&grammer_storage.version&&(_.size(grammer_storage.version)>=1)){
						if(stringService.compareWithoutCapital(grammer_storage.version, chrome.runtime.getManifest().version)){ resolve(); }
						else{ reject(); }
					}
					else{
						reject();
					}
				});
			};

			this.checkExcuteOnOfGrammerStorage = function(grammer_storage){
				var self = this;
				return $q(function(resolve, reject){
					if(grammer_storage&&grammer_storage.excute_on&&_.isBoolean(grammer_storage.excute_on)){ resolve(); }
					else{ reject(); }
				});
			};

			this.checkExcuteLogOnOfGrammerStorage = function(grammer_storage){
				var self = this;
				return $q(function(resolve, reject){
					if(grammer_storage&&grammer_storage.excute_log_on&&_.isBoolean(grammer_storage.excute_log_on)){ resolve(); }
					else{ reject(); }
				});
			};

			this.checkSetting = function(setting){
				if(!(setting&&angular.isDefined(setting.value))) return false;
				if(setting.type=='TIME') return _.isNumber(setting.value)&&(setting.value>=1);
				else if(setting.type=='TEXT') return _.isString(setting.value);
				else if(setting.type=='PERCENTAGE') return _.inRange( _.ceil(setting.value), -1, 101);
				else if(setting.type=='ARRAY') return _.isArray(setting.value); // false 반환
				else if(setting.type=='BOOLEAN') return _.isBoolean(setting.value); // false 반환 
				else if(setting.type=='NUMBER') return _.isNumber(setting.value)&&(setting.value>=1);
				else return true;
			};


		});

/***/ },
/* 14 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('grammerInitializeService', function($rootScope, $q, storageService, urlService, getService, grammerOriginalService, grammerCheckService){

			this.initializeDescriptionOfFunc = function(funcs, funcs_original, func_key){
				var self = this;
				return $q(function(resolve, reject){
					funcs[func_key].description = funcs_original[func_key].description;
					resolve();
				});
			};

			this.initializeIconOfFunc = function(funcs, funcs_original, func_key){
				var self = this;
				return $q(function(resolve, reject){
					funcs[func_key].icon = funcs_original[func_key].icon;
					resolve();
				});
			};

			this.initializeImageUrlOfFunc = function(funcs, funcs_original, func_key){
				var self = this;
				return $q(function(resolve, reject){
					funcs[func_key].image_url = funcs_original[func_key].image_url;
					resolve();
				});
			};

			this.initializeOnlyOfFunc = function(funcs, funcs_original, func_key){
				var self = this;
				return $q(function(resolve, reject){
					funcs[func_key].only = funcs_original[func_key].only;
					resolve();
				});
			};

			this.initializeIdOfFunc = function(funcs, funcs_original, func_key){
				var self = this;
				return $q(function(resolve, reject){
					funcs[func_key].id = funcs_original[func_key].id;
					resolve();
				});
			};

			this.initializeLogsOfFunc = function(funcs, funcs_original, func_key){
				var self = this;
				return $q(function(resolve, reject){
					if(!(funcs[func_key]&&funcs[func_key].logs&&funcs[func_key].logs.length>=1)){
						funcs[func_key].logs = funcs_original[func_key].logs;
					}
					resolve();
				});
			};

			this.initializeFunc = function(funcs, funcs_original, func_key){
				var self = this;
				return $q(function(resolve, reject){
					if(!funcs[func_key]){
						funcs[func_key] = funcs_original[func_key];
						resolve();
						return;
					}
					var promises = [];
					promises.push( self.initializeDescriptionOfFunc(funcs, funcs_original, func_key) );
					promises.push( self.initializeIconOfFunc(funcs, funcs_original, func_key) );
					promises.push( self.initializeImageUrlOfFunc(funcs, funcs_original, func_key) );
					promises.push( self.initializeOnlyOfFunc(funcs, funcs_original, func_key) );
					promises.push( self.initializeIdOfFunc(funcs, funcs_original, func_key) );
					promises.push( self.initializeLogsOfFunc(funcs, funcs_original, func_key) );
					$q.all(promises).then(function(){ resolve(); }, function(){ reject(); });
				});
			};

			this.initializeFuncsOfVersion = function(versions, versions_original, versions_original_key){
				var self = this;
				return $q(function(resolve, reject){
					if(!(versions[versions_original_key].funcs&&_.size(versions_original[versions_original_key].funcs)>=1)){
						versions[versions_original_key].funcs = versions_original[versions_original_key].funcs;
						resolve();
						return;
					}
					var func_original_index = 0;
					angular.forEach(versions_original[versions_original_key].funcs, function(func_value, func_key){
						func_original_index += 1;
						self.initializeFunc(versions[versions_original_key].funcs, versions_original[versions_original_key].funcs, func_key).then(function(){
							if(func_original_index==_.size(versions_original[versions_original_key].funcs)) resolve();
						}, function(){ reject(); });
					});
				});
			};

			this.initializeValueOfSetting = function(setting){
				if(!grammerCheckService.checkSetting(setting)){
					setting.value = setting.default;
				}
			};

			this.initializeDescriptionOfSetting = function(settings, settings_original, setting_key){
				return $q(function(resolve, reject){
					settings[setting_key].description = settings_original[setting_key].description;
					resolve();
				});
			};

			this.initializeTypeOfSetting = function(settings, settings_original, setting_key){
				return $q(function(resolve, reject){
					settings[setting_key].type = settings_original[setting_key].type;
					resolve();
				})
			};

			this.initializeQuestionOfSetting = function(settings, settings_original, setting_key){
				return $q(function(resolve, reject){
					settings[setting_key].question = settings_original[setting_key].question;
					resolve();
				})
			};

			this.initializeDefaultOfSetting = function(settings, settings_original, setting_key){
				return $q(function(resolve, reject){
					settings[setting_key].default = settings_original[setting_key].default;
					resolve();
				})
			};

			this.initializeIdOfSetting = function(settings, settings_original, setting_key){
				return $q(function(resolve, reject){
					settings[setting_key].id = settings_original[setting_key].id;
					resolve();
				})
			};

			this.initializeRecommendOfSetting = function(settings, settings_original, setting_key){
				return $q(function(resolve, reject){
					settings[setting_key].recommend = settings_original[setting_key].recommend;
					resolve();
				})
			};

			this.initializeConditionOfSetting = function(settings, settings_original, setting_key){
				return $q(function(resolve, reject){
					settings[setting_key].condition = settings_original[setting_key].condition;
					resolve();
				})
			};

			this.initializeSetting = function(settings, settings_original, setting_key){
				var self = this;
				return $q(function(resolve, reject){
					if(!settings[setting_key]){
						settings[setting_key] = settings_original[setting_key];
						resolve();
						return;
					}
					var promises = [];
					promises.push(self.initializeDescriptionOfSetting(settings, settings_original, setting_key));
					promises.push(self.initializeTypeOfSetting(settings, settings_original, setting_key));
					promises.push(self.initializeQuestionOfSetting(settings, settings_original, setting_key));
					promises.push(self.initializeDefaultOfSetting(settings, settings_original, setting_key));
					promises.push(self.initializeIdOfSetting(settings, settings_original, setting_key));
					promises.push(self.initializeRecommendOfSetting(settings, settings_original, setting_key));
					promises.push(self.initializeConditionOfSetting(settings, settings_original, setting_key));
					$q.all(promises).then(function(){
						self.initializeValueOfSetting(settings[setting_key]);
						resolve();
					}, function(){ reject(); });
				});
			};

			this.initializeSettingsOfVersion = function(versions, versions_original, versions_original_key){
				var self = this;
				return $q(function(resolve, reject){
					if(!(versions[versions_original_key].settings&&_.size(versions_original[versions_original_key].settings)>=1)){
						versions[versions_original_key].settings = versions_original[versions_original_key].settings;
						resolve(versions[versions_original_key].settings);
						return;
					}
					var settings_original_index = 0;
					angular.forEach(versions_original[versions_original_key].settings, function(setting_value, setting_key){
						settings_original_index += 1;
						self.initializeSetting(versions[versions_original_key].settings, versions_original[versions_original_key].settings, setting_key).then(function(){
							if(settings_original_index==_.size(versions_original[versions_original_key].settings)) resolve(versions[versions_original_key].settings);
						},function(){ reject(); });
					});
				});
			};

			this.initializeDescriptionOfVersion = function(versions, versions_original, versions_original_key){
				var self = this;
				return $q(function(resolve, reject){
					if(!angular.isDefined(versions[versions_original_key])) versions[versions_original_key] = {};
					versions[versions_original_key].description = versions_original[versions_original_key].description;
					resolve();
				});
			};

			this.initializeIdOfVersion = function(versions, versions_original, versions_original_key){
				var self = this;
				return $q(function(resolve, reject){
					versions[versions_original_key].id = versions_original[versions_original_key].id;
					resolve();
				});
			};

			this.initializeVersion = function(versions, versions_original, versions_original_key){
				var self = this;
				return $q(function(resolve, reject){
					var promises = [];
					promises.push(self.initializeDescriptionOfVersion(versions, versions_original, versions_original_key));
					promises.push(self.initializeSettingsOfVersion(versions, versions_original, versions_original_key));
					promises.push(self.initializeFuncsOfVersion(versions, versions_original, versions_original_key));
					promises.push(self.initializeIdOfVersion(versions, versions_original, versions_original_key));
					$q.all(promises).then(function(){ resolve(); }, function(){ reject(); })
				});
			};

			// 호출: self.initializeVersionsOfGrammer(grammer, grammer_original)
			this.initializeVersionsOfGrammer = function(grammer, grammer_original){
				var self = this;
				return $q(function(resolve, reject){
					if(!(grammer.version_key&&_.hasIn(grammer_original.versions, grammer.version_key))){
						grammer.version_key = _.keys(grammer_original.versions)[0];
					}
					if(!(grammer.versions&&_.size(grammer_original.versions)>=1)){
						grammer.versions = grammer_original.versions;
						resolve();
						return;
					}
					var grammer_original_version_index = 0;
					angular.forEach(grammer_original.versions, function(grammer_original_version_value, grammer_original_version_key){
						grammer_original_version_index += 1;
						self.initializeVersion(grammer.versions, grammer_original.versions, grammer_original_version_key).then(function(){
							if(grammer_original_version_index==_.size(grammer_original.versions)){
								resolve();
							}
						},function(){
							reject();
						});
					});
				});
			};

			// 호출: self.initializePropertyOfGrammer(grammers[grammer_key], grammers_original[grammer_key], grammer_original_key)
			this.initializePropertyOfGrammer = function(grammer, grammer_original, grammer_original_key){
				var self = this;
				return $q(function(resolve, reject){
					if(grammer_original_key!='versions'){
						grammer[grammer_original_key] = grammer_original[grammer_original_key];
						resolve();
						return;
					}
					self.initializeVersionsOfGrammer(grammer, grammer_original).then(function(){ resolve(); },function(){ reject(); });
				});
			};

			// grammer_storage.grammers, grammers, grammer_key
			this.initializeGrammer = function(grammers, grammers_original, grammer_key){
				var self = this;
				return $q(function(resolve, reject){
					if(!(grammers[grammer_key]&&_.size(grammers[grammer_key])>=1)){
						grammers[grammer_key] = grammers_original[grammer_key];
						resolve();
						return;
					}
					var promises = [];
					var grammer_original_property_index = 0;
					angular.forEach(grammers_original[grammer_key], function(grammer_original_value, grammer_original_key){
						grammer_original_property_index += 1;
						promises.push(self.initializePropertyOfGrammer(grammers[grammer_key], grammers_original[grammer_key], grammer_original_key));
						if(grammer_original_property_index==_.size(grammers_original[grammer_key])){
							$q.all(promises).then(function(){ resolve(); }, function(){ reject(); });
						}
					});
				});
			};

			this.initializeGrammersOfGrammerStorage = function(grammer_storage){
				var self = this;
				return $q(function(resolve, reject){
					if(!(grammer_storage.grammers&&_.size(grammer_storage.grammers)>=1)){
						grammer_storage.grammers = angular.copy(grammerOriginalService.grammers);
						// resolve(grammer_storage.grammers);
						// return;
					}
					var promises = [];
					var grammer_index = 0;
					var grammers = angular.copy(grammerOriginalService.grammers);
					angular.forEach(grammers, function(grammer_value, grammer_key){
						grammer_index += 1;
						promises.push(self.initializeGrammer(grammer_storage.grammers, grammers, grammer_key));
						if(grammer_index == _.size(grammers)){
							$q.all(promises).then(function(){ resolve(grammer_storage.grammers); }, function(){ reject(); });
						}
					});
				});
			};

			this.initializeVersionOfGrammerStorage = function(grammer_storage){
				var self = this;
				return $q(function(resolve, reject){
					grammerCheckService.checkVersionOfGrammerStorage(grammer_storage).then(function(){
						resolve(grammer_storage.version);
					}, function(){
						grammer_storage.version = chrome.runtime.getManifest().version;
						resolve();
					});
				});
			};

			this.initializeExcuteOnOfGrammerStorage = function(grammer_storage){
				var self = this;
				return $q(function(resolve, reject){
					grammerCheckService.checkExcuteOnOfGrammerStorage(grammer_storage).then(function(){
						resolve(grammer_storage.excute_on);
					}, function(){
						grammer_storage.excute_on = true;
						resolve();
					});
				});
			};

			this.initializeExcuteLogOnOfGrammerStorage = function(grammer_storage){
				var self = this;
				return $q(function(resolve, reject){
					grammerCheckService.checkExcuteLogOnOfGrammerStorage(grammer_storage).then(function(){
						resolve(grammer_storage.excute_log_on);
					}, function(){
						grammer_storage.excute_log_on = true;
						resolve();
					});
				});
			};

			this.initializeCurrentFuncKeyOfGrammerStorage = function(grammer_storage){
				var self = this;
				return $q(function(resolve, reject){
					grammerCheckService.checkCurrentFuncKeyOfGrammerStorage(grammer_storage).then(function(){
						resolve(grammer_storage.current_func_key);
					}, function(){
						grammer_storage.current_func_key = null;
						resolve();
					});
				});
			};

			// grammerInitializeService.initializeGrammerStorage 서비스에 현재 tab의 id를 등록한다.
			this.initializeGrammerStorage = function(grammer_storage){
				var self = this;
				return $q(function(resolve, reject){
					var execute = function(grammer_storage){
						var promises = [];
						promises.push(self.initializeExcuteOnOfGrammerStorage(grammer_storage));
						promises.push(self.initializeExcuteLogOnOfGrammerStorage(grammer_storage));
						promises.push(self.initializeVersionOfGrammerStorage(grammer_storage));
						promises.push(self.initializeGrammersOfGrammerStorage(grammer_storage));
						promises.push(self.initializeCurrentFuncKeyOfGrammerStorage(grammer_storage));
						$q.all(promises).then(function(){
							storageService.set('grammer_storage', grammer_storage);
							resolve(grammer_storage);
						}, function(){
							storageService.set('grammer_storage', grammer_storage);
							reject();
						});
					};
					if(grammer_storage){
						execute(grammer_storage);
					}
					else{
						var grammer_storage;
						storageService.get('grammer_storage').then(function(grammer_storage_local){
							grammer_storage = grammer_storage_local;
							execute(grammer_storage);
						}, function(){
							grammer_storage = {};
							execute(grammer_storage);
						});
					}
				});
			};
		});


/***/ },
/* 15 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.service('grammerSetService', function($rootScope, $q, storageService, getService, grammerGetService, grammerCheckService){
			this.setGrammerStorage = function(grammer_storage){
				return $q(function(resolve, reject){
					storageService.set('grammer_storage', grammer_storage);
					$rootScope.grammer_storage = grammer_storage;
					resolve(grammer_storage);
				});
			};

			this.setGrammerKey = function(grammer_key){
				var self = this;
				return $q(function(resolve, reject){
					grammerGetService.getGrammerStorage().then(function(grammer_storage_get){
						grammer_storage_get.grammer_key = grammer_key;
						self.setGrammerStorage(grammer_storage_get).then(function(grammer_storage_set){
							resolve(grammer_storage_set.grammer_key);
						}, function(){
							reject();
						});
					},function(){
						reject();
					});
				});
			};

			this.setGrammers = function(grammers){
				var self = this;
				return $q(function(resolve, reject){
					grammerGetService.getGrammerStorage().then(function(grammer_storage_get){
						grammer_storage_get.grammers = grammers;
						self.setGrammerStorage(grammer_storage_get).then(function(grammer_storage_set){
							resolve(grammer_storage_set.grammers);
						}, function(){
							reject();
						});
					}, function(){
						reject();
					});
				});
			};

			this.setGrammer = function(grammer_key, grammer_value){
				var self = this;
				return $q(function(resolve, reject){
					grammerGetService.getGrammers().then(function(grammers_get){
						grammers_get[grammer_key] = grammer_value;
						self.setGrammers(grammers_get).then(function(grammers_set){
							resolve(grammers_set[grammer_key]);
						}, function(){
							reject();
						});
					}, function(){
						reject();
					});
				});
			};

			this.setVersionKey = function(grammer_key, version_key){
				var self = this;
				return $q(function(resolve, reject){
					grammerGetService.getGrammer(grammer_key).then(function(grammer_get){
						grammer_get.version_key = version_key;
						self.setGrammer(grammer_key, grammer_get).then(function(grammer_set){
							resolve(grammer_set.version_key);
						}, function(){
							reject();
						});
					}, function(){
						reject();
					});
				});
			};

			this.setVersions = function(grammer_key, versions){
				var self = this;
				return $q(function(resolve, reject){
					grammerGetService.getGrammer(grammer_key).then(function(grammer_get){
						grammer_get.versions = versions;
						self.setGrammer(grammer_key, grammer_get).then(function(grammer_set){
							resolve(grammer_set.versions);
						}, function(){
							reject();
						});
					}, function(){
						reject();
					});
				});
			};

			this.setVersion = function(grammer_key, version_key, version_value){
				var self = this;
				return $q(function(resolve, reject){
					grammerGetService.getVersions(grammer_key).then(function(versions_get){
						versions_get[version_key] = version_value;
						self.setVersions(grammer_key, versions_get).then(function(versions_set){
							resolve(versions_set[version_key]);
						}, function(){
							reject();
						});
					}, function(){
						reject();
					});
				});
			};

			this.setSettings = function(grammer_key, version_key, settings){
				var self = this;
				return $q(function(resolve, reject){
					grammerGetService.getVersion(grammer_key, version_key).then(function(version_get){
						version_get.settings = settings;
						self.setVersion(grammer_key, version_key, version_get).then(function(version_set){
							resolve(version_set.settings);
						}, function(){
							reject();
						});
					}, function(){
						reject();
					});
				});
			};

		})


/***/ },
/* 16 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.filter('capitalize', function() {
		  return function(input) {
		    return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
		  }
		})
		.filter('objOrder', function () {
	    return function(object) {
	      var array = [];
	      angular.forEach(object, function (value, key) {
	          array.push({key: key, value: value});
	      });
	      return array;
	    };
	  })
	  .filter('returnUnit', function(){
	  	return function(setting_value){
	  		var unit = null;
	  		if(setting_value.type=='TIME'){
	        if(setting_value.type_two=='MINUTE') unit = '분';
	        else unit = '초';
	      }
	  		else if(setting_value.type=='PERCENTAGE') unit = '%';
	  		else if(setting_value.type=='BOOLEAN') unit = 'true/false';
	  		else if(setting_value.type=='NUMBER') unit = '개';
	  		return unit;
	  	}
	  })


/***/ },
/* 17 */
/***/ function(module, exports) {

	'use strict';

	angular.module('grammer_extension')
		.controller('ListCtrl', function ($scope, $rootScope, grammerGetService, grammerInitializeService, grammerSetService) {
			// Set Function Section
			$scope.setGrammerKeyOfGrammerStorage = function(grammer_key){
				$scope.grammer_storage.grammer_key = grammer_key;
			};

			// Initialize Function Section
			$scope.initialize = function(){
				grammerInitializeService.initializeGrammerStorage().then(function(grammer_storage){
					$scope.grammer_storage = grammer_storage;
					// $scope.setGrammerKeyOfGrammerStorageWithUrl();
				}, function(){
					return;
				});
			};
			$scope.initialize();
		});


/***/ },
/* 18 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.directive("listDir", function ($rootScope) {
			return {
				link: function (scope, element, attrs) {

					// Set Function Section
					scope.setGrammer = function(grammer_key){
						$rootScope.setGrammer(grammer_key);
					};

					// Select Function Section
					scope.selectGrammer = function(){
						$rootScope.setGrammer(scope.grammer_key);
					};

				},
				replace: true,
				scope:{
					grammer_storage:"=grammerStorage",
					grammer_key:"=grammerKey",
					grammer_value:"=grammerValue"
				},
				restrict:"EA",
				templateUrl: 'templates_extension/list/listDir.html'
			};
		});

/***/ },
/* 19 */
/***/ function(module, exports) {

	'use strict';

	angular.module('grammer_extension')
		.controller('DetailCtrl', function ($rootScope, $scope, $timeout, $filter, $state, cookieService, grammerOriginalService, grammerGetService, grammerCheckService, grammerSetService) {

			// Save Function Section
			$scope.saveSettings = function(){
				var settings_get_index = 0;
				angular.forEach($scope.grammer_value.versions[$scope.grammer_value.version_key].settings, function(setting_value, setting_key){

					settings_get_index += 1;
					// setting_value.type이 ARRAY, BOOLEAN인 경우에 저장하기에 적합한 형태로 바꿔주는 로직.
					if(setting_value.type=='ARRAY'){
						// var stringsOfSetting = String(setting_value.value);
						var stringsOfSetting = setting_value.value.toString();
						var arrayOfSetting = stringsOfSetting.split(",");
						setting_value.value = arrayOfSetting;
					}
					else if(setting_value.type=='BOOLEAN'){ 
						var boolean_value;
						setting_value.value = $filter('lowercase')(setting_value.value);
						if((setting_value.value=='true')||(setting_value.value===true)){
							boolean_value = true;
							setting_value.value = boolean_value;
						}
						else if((setting_value.value=='false')||(setting_value.value===false)){
							boolean_value = false;
							setting_value.value = boolean_value;
						}
					}
					else if(setting_value.type=='TEXT'||setting_value.type=="PASSWORD"){
						setting_value.value = setting_value.value;
					}
					// 각 셋팅들이 각 변수종류에 맞는지 확인하고 맞다면 그냥 받아온 값을 집어넣고, 아니면 setting_value.default값을 setting_value.value값에 설정한다.
					if(!grammerCheckService.checkSetting(setting_value)) setting_value.value = setting_value.default;
					if(settings_get_index == _.size($scope.grammer_value.versions[$scope.grammer_value.version_key].settings)){
						grammerSetService.setSettings($scope.grammer_key, $scope.grammer_value.version_key, $scope.grammer_value.versions[$scope.grammer_value.version_key].settings).then(function(settings_set){
							$scope.grammer_value.versions[$scope.grammer_value.version_key].settings = settings_set;
						});
					}
				});
			};

			// Cancel Function Section
			$scope.cancelSettings = function(){
				grammerGetService.getSettings($scope.grammer_key, $scope.grammer_value.version_key).then(function(settings){
					$scope.grammer_value.versions[$scope.grammer_value.version_key].settings = settings;
					window.close();
				});
			};

			// Initialize Function Section
			$scope.initializeSettings = function(){
				var settings_get = angular.copy(grammerOriginalService.grammers[$scope.grammer_key].versions[$scope.grammer_value.version_key].settings);
				var settings_get_index = 0;
				angular.forEach(settings_get, function(setting_value, setting_key){
					settings_get_index += 1;
					if(!grammerCheckService.checkSetting(setting_value)) setting_value.value = setting_value.default;
					if(settings_get_index == _.size(settings_get)){
						grammerSetService.setSettings($scope.grammer_key, $scope.grammer_value.version_key, settings_get).then(function(settings_set){
							$scope.grammer_value.versions[$scope.grammer_value.version_key].settings = settings_set;
						});
					}
				});
			};

			// Initialize Function Section
			$scope.initialize = function(){
				if(!($state.params&&$state.params.id)) return;
				$scope.grammer_key = $state.params.id;
				grammerGetService.getGrammer($scope.grammer_key).then(function(grammer_value){
					$scope.grammer_value = grammer_value;
				}, function(){
					$rootScope.goToPage('list');
					return;
				});
			};

			// Watch Function Section
			var timeoutPromise;
			$rootScope.$watch('state', function(newValue, oldValue){
				if($rootScope.state=='detail/:id') {
					$timeout.cancel(timeoutPromise);
					timeoutPromise = $timeout(function(){
						$scope.initialize();
					},100);
				}
			});
	});


/***/ },
/* 20 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.directive("headerDir", function ($rootScope, $filter, $timeout, $state, grammerGetService) {
			return {
				link: function (scope, element, attrs) {

					// Go Function Section
					scope.goBack = function(func){
						$rootScope.goToPage('list');
					};

					// Initialize Function Section
					scope.initialize = function(){
						if(!($state.params&&$state.params.id)) return;
						scope.grammer_key = $state.params.id;
					};

					// Watch Function Section
					var timeoutPromise;
					$rootScope.$watch('state', function(newValue, oldValue){ 
						if($rootScope.state=='detail/:id') {
							$timeout.cancel(timeoutPromise);
							timeoutPromise = $timeout(function(){
								scope.initialize();
							},100); 
						}
					});
				},
				replace: true,
				scope:{
				},
				restrict:"EA",
				templateUrl: 'templates_extension/header/headerDir.html'
			};
		});

/***/ },
/* 21 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.directive("settingsDir", function ($rootScope, $filter, booleanService, stringService, grammerSetService) {
			return {
				link: function (scope, element, attrs) {
					
					// Click Function Section
					scope.clickVersion = function(version_key){
						grammerSetService.setVersionKey(scope.grammer_key, version_key).then(function(version_key){
							scope.grammer_value.version_key=version_key;
						});
					};

				},
				replace: true,
				scope:{
					grammer_value : "=grammerValue",
					grammer_key : "=grammerKey"
				},
				restrict:"EA",
				templateUrl: 'templates_extension/setting/settingsDir.html'
			};
		});

/***/ },
/* 22 */
/***/ function(module, exports) {

	'use strict';

	angular.module("grammer_extension")
		.directive("settingDir", function ($rootScope, $filter, booleanService, stringService) {
			return {
				link: function (scope, element, attrs) {

					// Toggle Function Section
					scope.toggleClick = function(boolean){
						if(angular.isDefined(boolean)) scope.setting_value.click = booleanService.makeBoolean(boolean);
						else{ scope.setting_value.click = !scope.setting_value.click; }
					};

					scope.$watch('setting_value.click', function() {
						if(scope.setting_value.click){
							angular.forEach(scope.settings, function(setting, setting_key){
								if(!stringService.compareWithoutCapital(setting.description, scope.setting_value.description)){
									setting.click = false;
								}
							});
						}
					});
				},
				replace: true,
				scope:{
					setting_key : "=settingKey",
					setting_value : "=settingValue",
					settings : "=settings"
				},
				restrict:"EA",
				templateUrl: 'templates_extension/setting/settingDir.html'
			};
		});

/***/ }
/******/ ]);