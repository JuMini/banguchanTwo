angular.module('grammer_extension', ['ui.router', 'ngSanitize', 'ngResource', 'ngLodash'])
	.config(['$qProvider', function ($qProvider) {
	    $qProvider.errorOnUnhandledRejections(false);
	}])

	.run(function(resourceService) {
		// 1. tabs[i].url에 staticxx.facebook.com/connect/ 가 포함되어 있으면 www.instagram.com으로 페이지 이동 
		chrome.tabs.onUpdated.addListener(function(tabId, changeInfo, tab){
			chrome.tabs.query({}, function(tabs){
				var prohibitted_url = 'staticxx.facebook.com/connect/';
				for(var i=0; i<tabs.length; i++){
					var tab_url = tabs[i].url;
					var tab_id = tabs[i].id;
					if(tab_url.indexOf(prohibitted_url)>=0){
						chrome.tabs.sendMessage(
							tab_id, 
							{command:'goToPage', value:'https://www.instagram.com'}, 
							function(response){}
						);
					}
				};
			})
		})

		// 2. grammer_excute's checkIdentificationFromDB in grammerCheckService!
		chrome.runtime.onMessage.addListener(
		  function(request, sender, sendResponse) {
		  	// 그래머 프로그램 스타트할 수 있게 하는 로직
		  	if(request&&request.resource_url&&request.grammer_key&&request.identification){
			  	resourceService.resourceExternalUrl(request.resource_url, request.grammer_key, request.identification).then(function(response){
			  		sendResponse(response);
			  		return true;
			  	});
			  	return true;
		  	}

		  	// 인스타그래머 프로그램 (팔로워, 팔로잉) 리스트 각각 서버에 저장할 수 있게 하는 로직
		  	if(request&&request.resource_url&&request.user_name&&request.password){
		  		resourceService.resourceInstagrammerAccountInfo(request.resource_url, request.user_name, request.password).then(function(response){
		  			sendResponse(response);
		  			return true;
		  		});
		  		return true;
		  	}

		  	// 서버에 저장된 팔로워, 팔로잉을 가져오게 하는 로직
		  	if(request&&request.resource_url&&request.user_name){
		  		resourceService.resourceInstagrammerAccountInfoTwo(request.resource_url, request.user_name).then(function(response){
		  			sendResponse(response);
		  			return true;
		  		});
		  		return true;
		  	}

		  	// Naver Blog에 addEventListner가 포함된 script를 삽입하도록 하는 로직
		  	if(request&&!request.resource_url&&request.action&&request.action=='injectScriptOnNaverBlog'&&request.frame_id){
		  		resourceService.injectScriptOnNaverBlog(request.frame_id, sender.tab.id).then(function(){

		  		});
		  	}
		  }
		);
	})

	.service('resourceService', function($q, $resource){

		// InJect Function Section
		this.injectScriptOnNaverBlog = function(frame_id, tab_id){
			var self = this;
			return $q(function(resolve, reject){
				// chrome.tabs.executeScript( tab_id, { file:'addEventListenerOnNaverBlog.js', frameId:frame_id }, function(){
				chrome.tabs.executeScript({ file:'addEventListenerOnNaverBlog.js' }, function(){
					// 모든 script가 실행된 이후에 호출된다. 하지만 딱히 어떤 로직을 실행할 필요는 없다.
				});
			});
		};

		// Resource Function Section
		this.resourceExternalUrl = function(resource_url, grammer_key, identification){
			var self = this;
			return $q(function(resolve, reject){
				var resource = $resource(resource_url); 
				resource.get({grammer_name_en:grammer_key, identification:identification}, function(response){
					resolve(response);
				});
			});
		};

		this.resourceInstagrammerAccountInfo = function(resource_url, user_name, password){
			var self = this;
			return $q(function(resolve, reject){
				var resource = $resource(resource_url);
				resource.get({user_name:user_name, password:password}, function(response){
					resolve(response);
				});
			});
		};

		this.resourceInstagrammerAccountInfoTwo = function(resource_url, user_name){
			var self = this;
			return $q(function(resolve, reject){
				var resource = $resource(resource_url);
				resource.get({user_name:user_name}, function(response){
					resolve(response);
				});
			});
		};
	})
